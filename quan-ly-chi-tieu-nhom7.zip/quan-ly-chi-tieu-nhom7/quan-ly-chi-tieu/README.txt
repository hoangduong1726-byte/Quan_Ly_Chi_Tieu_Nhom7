HƯỚNG DẪN CÀI ĐẶT VÀ CHẠY
ỨNG DỤNG QUẢN LÝ CHI TIÊU CÁ NHÂN

========================================
1. CƠ SỞ DỮ LIỆU
========================================

File database:
database/quan_ly_chi_tieu.sql

Mở MySQL Workbench và import file:
quan_ly_chi_tieu.sql

Database sử dụng:
quan_ly_chi_tieu

Sau khi import, kiểm tra có 5 bảng:
- users
- categories
- wallets
- transactions
- budgets


========================================
2. CẤU HÌNH BACKEND
========================================

Mở file:
server/.env

Cấu hình thông tin MySQL phù hợp với máy đang chạy.

Ví dụ:

DB_HOST=localhost
DB_USER=root
DB_PASSWORD=mat_khau_mysql
DB_NAME=quan_ly_chi_tieu
DB_PORT=3306

PORT=5000
JWT_SECRET=quan_ly_chi_tieu

Lưu ý:
DB_USER, DB_PASSWORD và DB_PORT cần thay đổi
theo cấu hình MySQL của máy đang sử dụng.


========================================
3. CHẠY BACKEND
========================================

Mở Terminal tại thư mục server:

cd server

Cài thư viện:

npm install

Chạy server:

node server.js

Backend chạy tại:

http://localhost:5000


========================================
4. CHẠY FRONTEND
========================================

Mở Terminal mới tại thư mục client:

cd client

Cài thư viện:

npm install

Chạy ReactJS:

npm run dev

Sau đó mở đường dẫn Vite hiển thị trên Terminal,
thông thường:

http://localhost:5173


========================================
5. CÔNG NGHỆ SỬ DỤNG
========================================

Frontend:
- ReactJS
- Vite
- React Router
- Axios
- Recharts

Backend:
- Node.js
- Express
- JWT
- bcrypt

Database:
- MySQL