const express = require("express");
const pool = require("../config/db");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

router.use(authMiddleware);
// TỔNG QUAN THU - CHI THEO THÁNG/NĂM
router.get("/summary", async (req, res) => {
  try {
    const userId = req.user.id;

    const month = Number(req.query.month);
    const year = Number(req.query.year);

    if (
      !month ||
      !year ||
      month < 1 ||
      month > 12
    ) {
      return res.status(400).json({
        message: "Tháng hoặc năm không hợp lệ",
      });
    }

    const [rows] = await pool.query(
      `SELECT
        COALESCE(
          SUM(
            CASE
              WHEN type = 'income'
              THEN amount
              ELSE 0
            END
          ),
          0
        ) AS total_income,

        COALESCE(
          SUM(
            CASE
              WHEN type = 'expense'
              THEN amount
              ELSE 0
            END
          ),
          0
        ) AS total_expense

       FROM transactions

       WHERE user_id = ?
         AND MONTH(transaction_date) = ?
         AND YEAR(transaction_date) = ?`,
      [userId, month, year]
    );

    const totalIncome = Number(
      rows[0].total_income
    );

    const totalExpense = Number(
      rows[0].total_expense
    );

    res.json({
      total_income: totalIncome,
      total_expense: totalExpense,
      balance: totalIncome - totalExpense,
    });
  } catch (error) {
    console.error("Lỗi summary:", error);

    res.status(500).json({
      message: "Không thể lấy dữ liệu tổng quan",
    });
  }
});

// CHI TIÊU THEO DANH MỤC + THÁNG/NĂM
router.get(
  "/expense-by-category",
  async (req, res) => {
    try {
      const userId = req.user.id;

      const month = Number(req.query.month);
      const year = Number(req.query.year);

      if (
        !month ||
        !year ||
        month < 1 ||
        month > 12
      ) {
        return res.status(400).json({
          message: "Tháng hoặc năm không hợp lệ",
        });
      }

      const [rows] = await pool.query(
        `SELECT
          c.id,
          c.name,
          c.icon,
          c.color,

          COALESCE(
            SUM(t.amount),
            0
          ) AS total

         FROM transactions t

         JOIN categories c
           ON t.category_id = c.id

         WHERE t.user_id = ?
           AND t.type = 'expense'
           AND MONTH(t.transaction_date) = ?
           AND YEAR(t.transaction_date) = ?

         GROUP BY
           c.id,
           c.name,
           c.icon,
           c.color

         ORDER BY total DESC`,
        [userId, month, year]
      );

      res.json(rows);
    } catch (error) {
      console.error(
        "Lỗi expense-by-category:",
        error
      );

      res.status(500).json({
        message:
          "Không thể lấy chi tiêu theo danh mục",
      });
    }
  }
);

// THU - CHI THEO THÁNG
router.get("/monthly", async (req, res) => {
  try {
    const userId = req.user.id;

    const [rows] = await pool.query(
      `SELECT
        YEAR(transaction_date) AS year,
        MONTH(transaction_date) AS month,

        COALESCE(
          SUM(
            CASE
              WHEN type = 'income'
              THEN amount
              ELSE 0
            END
          ),
          0
        ) AS income,

        COALESCE(
          SUM(
            CASE
              WHEN type = 'expense'
              THEN amount
              ELSE 0
            END
          ),
          0
        ) AS expense

       FROM transactions

       WHERE user_id = ?

       GROUP BY
         YEAR(transaction_date),
         MONTH(transaction_date)

       ORDER BY
         YEAR(transaction_date),
         MONTH(transaction_date)`,
      [userId]
    );

    res.json(rows);
  } catch (error) {
    console.error("Lỗi monthly:", error);

    res.status(500).json({
      message:
        "Không thể lấy thống kê theo tháng",
    });
  }
});


module.exports = router;