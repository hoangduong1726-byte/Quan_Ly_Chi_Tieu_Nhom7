const express = require("express");
const pool = require("../config/db");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

router.use(authMiddleware);

const applyTransactionToWallet = async (
  connection,
  walletId,
  userId,
  type,
  amount
) => {
  const money = Number(amount);

  if (type === "income") {
    await connection.query(
      `UPDATE wallets
       SET balance = balance + ?
       WHERE id = ?
       AND user_id = ?`,
      [money, walletId, userId]
    );
  } else {
    await connection.query(
      `UPDATE wallets
       SET balance = balance - ?
       WHERE id = ?
       AND user_id = ?`,
      [money, walletId, userId]
    );
  }
};

const reverseTransactionFromWallet = async (
  connection,
  walletId,
  userId,
  type,
  amount
) => {
  const money = Number(amount);

  if (type === "income") {
    await connection.query(
      `UPDATE wallets
       SET balance = balance - ?
       WHERE id = ?
       AND user_id = ?`,
      [money, walletId, userId]
    );
  } else {
    await connection.query(
      `UPDATE wallets
       SET balance = balance + ?
       WHERE id = ?
       AND user_id = ?`,
      [money, walletId, userId]
    );
  }
};

router.get("/", async (req, res) => {
  try {
    const [transactions] = await pool.query(
      `SELECT
        t.id,
        t.type,
        t.amount,
        t.transaction_date,
        t.note,

        t.category_id,
        c.name AS category_name,
        c.icon AS category_icon,
        c.color AS category_color,

        t.wallet_id,
        w.name AS wallet_name

       FROM transactions t

       JOIN categories c
         ON t.category_id = c.id

       JOIN wallets w
         ON t.wallet_id = w.id

       WHERE t.user_id = ?

       ORDER BY t.transaction_date DESC, t.id DESC`,
      [req.user.id]
    );

    res.json(transactions);
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Không thể lấy danh sách giao dịch",
    });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [transactions] = await pool.query(
      `SELECT
        t.id,
        t.type,
        t.amount,
        t.transaction_date,
        t.note,

        t.category_id,
        c.name AS category_name,
        c.icon AS category_icon,
        c.color AS category_color,

        t.wallet_id,
        w.name AS wallet_name

       FROM transactions t

       JOIN categories c
         ON t.category_id = c.id

       JOIN wallets w
         ON t.wallet_id = w.id

       WHERE t.id = ?
       AND t.user_id = ?`,
      [id, req.user.id]
    );

    if (transactions.length === 0) {
      return res.status(404).json({
        message: "Không tìm thấy giao dịch",
      });
    }

    res.json(transactions[0]);
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Lỗi server",
    });
  }
});

router.post("/", async (req, res) => {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const {
      type,
      amount,
      category_id,
      wallet_id,
      transaction_date,
      note,
    } = req.body;

    const userId = req.user.id;
    const money = Number(amount);

    if (
      !type ||
      !amount ||
      !category_id ||
      !wallet_id ||
      !transaction_date
    ) {
      await connection.rollback();

      return res.status(400).json({
        message: "Vui lòng nhập đầy đủ thông tin",
      });
    }

    if (!["income", "expense"].includes(type)) {
      await connection.rollback();

      return res.status(400).json({
        message: "Loại giao dịch không hợp lệ",
      });
    }

    if (money <= 0) {
      await connection.rollback();

      return res.status(400).json({
        message: "Số tiền phải lớn hơn 0",
      });
    }

    const [categories] = await connection.query(
      `SELECT id
       FROM categories
       WHERE id = ?
       AND user_id = ?
       AND type = ?`,
      [category_id, userId, type]
    );

    if (categories.length === 0) {
      await connection.rollback();

      return res.status(400).json({
        message: "Danh mục không hợp lệ",
      });
    }

    const [wallets] = await connection.query(
      `SELECT id, balance
       FROM wallets
       WHERE id = ?
       AND user_id = ?
       FOR UPDATE`,
      [wallet_id, userId]
    );

    if (wallets.length === 0) {
      await connection.rollback();

      return res.status(400).json({
        message: "Ví không hợp lệ",
      });
    }

    const [result] = await connection.query(
      `INSERT INTO transactions
       (
         user_id,
         category_id,
         wallet_id,
         type,
         amount,
         transaction_date,
         note
       )
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        userId,
        category_id,
        wallet_id,
        type,
        money,
        transaction_date,
        note || null,
      ]
    );

    await applyTransactionToWallet(
      connection,
      wallet_id,
      userId,
      type,
      money
    );


    await connection.commit();

    res.status(201).json({
      message: "Thêm giao dịch thành công",
      id: result.insertId,
    });

  } catch (error) {
    await connection.rollback();

    console.error(error);

    res.status(500).json({
      message: "Lỗi server",
    });

  } finally {
    connection.release();
  }
});

router.put("/:id", async (req, res) => {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const { id } = req.params;

    const {
      type,
      amount,
      category_id,
      wallet_id,
      transaction_date,
      note,
    } = req.body;

    const userId = req.user.id;
    const money = Number(amount);


    if (
      !type ||
      !amount ||
      !category_id ||
      !wallet_id ||
      !transaction_date
    ) {
      await connection.rollback();

      return res.status(400).json({
        message: "Vui lòng nhập đầy đủ thông tin",
      });
    }

    if (!["income", "expense"].includes(type)) {
      await connection.rollback();

      return res.status(400).json({
        message: "Loại giao dịch không hợp lệ",
      });
    }

    if (money <= 0) {
      await connection.rollback();

      return res.status(400).json({
        message: "Số tiền phải lớn hơn 0",
      });
    }

    const [oldTransactions] =
      await connection.query(
        `SELECT
          id,
          wallet_id,
          type,
          amount
         FROM transactions
         WHERE id = ?
         AND user_id = ?
         FOR UPDATE`,
        [id, userId]
      );

    if (oldTransactions.length === 0) {
      await connection.rollback();

      return res.status(404).json({
        message: "Không tìm thấy giao dịch",
      });
    }

    const oldTransaction = oldTransactions[0];

    const [categories] =
      await connection.query(
        `SELECT id
         FROM categories
         WHERE id = ?
         AND user_id = ?
         AND type = ?`,
        [category_id, userId, type]
      );

    if (categories.length === 0) {
      await connection.rollback();

      return res.status(400).json({
        message: "Danh mục không hợp lệ",
      });
    }

    const [wallets] =
      await connection.query(
        `SELECT id
         FROM wallets
         WHERE id = ?
         AND user_id = ?
         FOR UPDATE`,
        [wallet_id, userId]
      );

    if (wallets.length === 0) {
      await connection.rollback();

      return res.status(400).json({
        message: "Ví không hợp lệ",
      });
    }
    await reverseTransactionFromWallet(
      connection,
      oldTransaction.wallet_id,
      userId,
      oldTransaction.type,
      oldTransaction.amount
    );

    await connection.query(
      `UPDATE transactions

       SET category_id = ?,
           wallet_id = ?,
           type = ?,
           amount = ?,
           transaction_date = ?,
           note = ?

       WHERE id = ?
       AND user_id = ?`,
      [
        category_id,
        wallet_id,
        type,
        money,
        transaction_date,
        note || null,
        id,
        userId,
      ]
    );
    await applyTransactionToWallet(
      connection,
      wallet_id,
      userId,
      type,
      money
    );


    await connection.commit();

    res.json({
      message: "Cập nhật giao dịch thành công",
    });

  } catch (error) {
    await connection.rollback();

    console.error(error);

    res.status(500).json({
      message: "Lỗi server",
    });

  } finally {
    connection.release();
  }
});


router.delete("/:id", async (req, res) => {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const { id } = req.params;
    const userId = req.user.id;


    const [transactions] =
      await connection.query(
        `SELECT
          id,
          wallet_id,
          type,
          amount
         FROM transactions
         WHERE id = ?
         AND user_id = ?
         FOR UPDATE`,
        [id, userId]
      );

    if (transactions.length === 0) {
      await connection.rollback();

      return res.status(404).json({
        message: "Không tìm thấy giao dịch",
      });
    }

    const transaction = transactions[0];


    await reverseTransactionFromWallet(
      connection,
      transaction.wallet_id,
      userId,
      transaction.type,
      transaction.amount
    );


    await connection.query(
      `DELETE FROM transactions
       WHERE id = ?
       AND user_id = ?`,
      [id, userId]
    );


    await connection.commit();

    res.json({
      message: "Xóa giao dịch thành công",
    });

  } catch (error) {
    await connection.rollback();

    console.error(error);

    res.status(500).json({
      message: "Không thể xóa giao dịch",
    });

  } finally {
    connection.release();
  }
});


module.exports = router;