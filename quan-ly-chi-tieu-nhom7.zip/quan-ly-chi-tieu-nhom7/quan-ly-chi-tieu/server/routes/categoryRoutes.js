const express = require("express");
const pool = require("../config/db");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();
router.use(authMiddleware);
// LẤY DANH SÁCH DANH MỤC
router.get("/", async (req, res) => {
  try {
    const [categories] = await pool.query(
      `SELECT id, name, type, icon, color
       FROM categories
       WHERE user_id = ?
       ORDER BY id DESC`,
      [req.user.id],
    );

    res.json(categories);
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Lỗi server",
    });
  }
});
// THÊM DANH MỤC
router.post("/", async (req, res) => {
  try {
    const { name, type, icon, color } = req.body;

    if (!name || !type) {
      return res.status(400).json({
        message: "Tên và loại danh mục là bắt buộc",
      });
    }

    if (!["income", "expense"].includes(type)) {
      return res.status(400).json({
        message: "Loại danh mục không hợp lệ",
      });
    }

    const [result] = await pool.query(
      `INSERT INTO categories
       (user_id, name, type, icon, color)
       VALUES (?, ?, ?, ?, ?)`,
      [req.user.id, name, type, icon || null, color || null],
    );

    res.status(201).json({
      message: "Thêm danh mục thành công",
      id: result.insertId,
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Lỗi server",
    });
  }
});
// SỬA DANH MỤC
router.put("/:id", async (req, res) => {
  try {
    const { name, type, icon, color } = req.body;
    const { id } = req.params;

    if (!name || !type) {
      return res.status(400).json({
        message: "Tên và loại danh mục là bắt buộc",
      });
    }

    if (!["income", "expense"].includes(type)) {
      return res.status(400).json({
        message: "Loại danh mục không hợp lệ",
      });
    }

    const [result] = await pool.query(
      `UPDATE categories
       SET name = ?, type = ?, icon = ?, color = ?
       WHERE id = ? AND user_id = ?`,
      [name, type, icon || null, color || null, id, req.user.id],
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Không tìm thấy danh mục",
      });
    }

    res.json({
      message: "Cập nhật danh mục thành công",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Lỗi server",
    });
  }
});
// XÓA DANH MỤC
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await pool.query(
      `DELETE FROM categories
       WHERE id = ? AND user_id = ?`,
      [id, req.user.id],
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Không tìm thấy danh mục",
      });
    }

    res.json({
      message: "Xóa danh mục thành công",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Không thể xóa danh mục",
    });
  }
});

module.exports = router;
