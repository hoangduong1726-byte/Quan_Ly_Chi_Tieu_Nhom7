const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const pool = require("../config/db");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// 1. ĐĂNG KÝ TÀI KHOẢN
router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        message: "Vui lòng nhập đầy đủ thông tin",
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        message: "Mật khẩu phải có ít nhất 6 ký tự",
      });
    }
    const [existingUsers] = await pool.query(
      "SELECT id FROM users WHERE email = ?",
      [email]
    );

    if (existingUsers.length > 0) {
      return res.status(400).json({
        message: "Email đã được sử dụng",
      });
    }

    const hashedPassword = await bcrypt.hash(
      password,
      10
    );

    const [result] = await pool.query(
      `INSERT INTO users
       (name, email, password)
       VALUES (?, ?, ?)`,
      [name, email, hashedPassword]
    );

    return res.status(201).json({
      message: "Đăng ký thành công",
      user: {
        id: result.insertId,
        name: name,
        email: email,
      },
    });

  } catch (error) {
    console.error("Lỗi đăng ký:", error);

    return res.status(500).json({
      message: "Lỗi server",
    });
  }
});
// 2. ĐĂNG NHẬP
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        message: "Vui lòng nhập email và mật khẩu",
      });
    }
    const [users] = await pool.query(
      "SELECT * FROM users WHERE email = ?",
      [email]
    );

    if (users.length === 0) {
      return res.status(400).json({
        message: "Email hoặc mật khẩu không đúng",
      });
    }

    const user = users[0];
    const isMatch = await bcrypt.compare(
      password,
      user.password
    );

    if (!isMatch) {
      return res.status(400).json({
        message: "Email hoặc mật khẩu không đúng",
      });
    }
    const token = jwt.sign(
      {
        id: user.id,
        email: user.email,
      },
      process.env.JWT_SECRET,
      {
        expiresIn: "1d",
      }
    );

    return res.json({
      message: "Đăng nhập thành công",

      token: token,

      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        birth_date: user.birth_date,
        gender: user.gender,
        avatar: user.avatar,
      },
    });

  } catch (error) {
    console.error("Lỗi đăng nhập:", error);

    return res.status(500).json({
      message: "Lỗi server",
    });
  }
});

// 3. LẤY THÔNG TIN NGƯỜI ĐANG ĐĂNG NHẬP
router.get("/me", authMiddleware, async (req, res) => {
  try {
    const [users] = await pool.query(
      `SELECT
        id,
        name,
        email,
        birth_date,
        gender,
        avatar,
        created_at
       FROM users
       WHERE id = ?`,
      [req.user.id]
    );

    if (users.length === 0) {
      return res.status(404).json({
        message: "Không tìm thấy người dùng",
      });
    }

    return res.json({
      user: users[0],
    });

  } catch (error) {
    console.error(
      "Lỗi lấy thông tin người dùng:",
      error
    );

    return res.status(500).json({
      message: "Lỗi server",
    });
  }
});


// 4. CẬP NHẬT HỒ SƠ
router.put(
  "/profile",
  authMiddleware,
  async (req, res) => {
    try {
      const {
        name,
        birth_date,
        gender,
        avatar,
      } = req.body;

      if (!name || !name.trim()) {
        return res.status(400).json({
          message:
            "Họ và tên không được để trống",
        });
      }

      const validGenders = [
        "Nam",
        "Nữ",
        "Khác",
      ];

      if (
        gender &&
        !validGenders.includes(gender)
      ) {
        return res.status(400).json({
          message: "Giới tính không hợp lệ",
        });
      }

      await pool.query(
        `UPDATE users
         SET name = ?,
             birth_date = ?,
             gender = ?,
             avatar = ?
         WHERE id = ?`,
        [
          name.trim(),
          birth_date || null,
          gender || null,
          avatar || null,
          req.user.id,
        ]
      );

      const [users] = await pool.query(
        `SELECT
          id,
          name,
          email,
          birth_date,
          gender,
          avatar,
          created_at
         FROM users
         WHERE id = ?`,
        [req.user.id]
      );

      return res.json({
        message:
          "Cập nhật hồ sơ thành công",
        user: users[0],
      });

    } catch (error) {
      console.error(
        "Lỗi cập nhật hồ sơ:",
        error
      );

      return res.status(500).json({
        message: "Lỗi server",
      });
    }
  }
);

// 5. ĐỔI MẬT KHẨU
router.put(
  "/change-password",
  authMiddleware,
  async (req, res) => {
    try {
      const {
        currentPassword,
        newPassword,
        confirmPassword,
      } = req.body;
      if (
        !currentPassword ||
        !newPassword ||
        !confirmPassword
      ) {
        return res.status(400).json({
          message:
            "Vui lòng nhập đầy đủ thông tin",
        });
      }

      if (newPassword.length < 6) {
        return res.status(400).json({
          message:
            "Mật khẩu mới phải có ít nhất 6 ký tự",
        });
      }

      if (newPassword !== confirmPassword) {
        return res.status(400).json({
          message:
            "Xác nhận mật khẩu không khớp",
        });
      }

      const [users] = await pool.query(
        `SELECT id, password
         FROM users
         WHERE id = ?`,
        [req.user.id]
      );

      if (users.length === 0) {
        return res.status(404).json({
          message:
            "Không tìm thấy người dùng",
        });
      }

      const user = users[0];

      const isMatch = await bcrypt.compare(
        currentPassword,
        user.password
      );

      if (!isMatch) {
        return res.status(400).json({
          message:
            "Mật khẩu hiện tại không đúng",
        });
      }

      const isSamePassword =
        await bcrypt.compare(
          newPassword,
          user.password
        );

      if (isSamePassword) {
        return res.status(400).json({
          message:
            "Mật khẩu mới phải khác mật khẩu hiện tại",
        });
      }

      const hashedPassword =
        await bcrypt.hash(
          newPassword,
          10
        );

      await pool.query(
        `UPDATE users
         SET password = ?
         WHERE id = ?`,
        [
          hashedPassword,
          req.user.id,
        ]
      );

      return res.json({
        message:
          "Đổi mật khẩu thành công",
      });

    } catch (error) {
      console.error(
        "Lỗi đổi mật khẩu:",
        error
      );

      return res.status(500).json({
        message: "Lỗi server",
      });
    }
  }
);


module.exports = router;