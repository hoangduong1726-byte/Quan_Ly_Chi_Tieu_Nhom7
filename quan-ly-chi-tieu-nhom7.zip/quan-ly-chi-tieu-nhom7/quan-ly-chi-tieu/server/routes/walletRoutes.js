const express = require("express");
const pool = require("../config/db");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

router.use(authMiddleware);

// LẤY DANH SÁCH VÍ
router.get("/", async (req, res) => {
  try {
    const [wallets] = await pool.query(
      `SELECT id, name, balance
       FROM wallets
       WHERE user_id = ?
       ORDER BY id DESC`,
      [req.user.id],
    );

    res.json(wallets);
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Lỗi server",
    });
  }
});

// THÊM VÍ
router.post("/", async (req, res) => {
  try {
    const { name, balance } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({
        message: "Vui lòng nhập tên ví",
      });
    }

    const walletBalance = Number(balance) || 0;

    if (walletBalance < 0) {
      return res.status(400).json({
        message: "Số dư ban đầu không được âm",
      });
    }

    const [result] = await pool.query(
      `INSERT INTO wallets (user_id, name, balance)
       VALUES (?, ?, ?)`,
      [req.user.id, name.trim(), walletBalance],
    );

    res.status(201).json({
      message: "Thêm ví thành công",
      id: result.insertId,
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Lỗi server",
    });
  }
});

// SỬA VÍ
router.put("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { name, balance } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({
        message: "Vui lòng nhập tên ví",
      });
    }

    const walletBalance = Number(balance);

    if (Number.isNaN(walletBalance) || walletBalance < 0) {
      return res.status(400).json({
        message: "Số dư không hợp lệ",
      });
    }

    const [result] = await pool.query(
      `UPDATE wallets
       SET name = ?, balance = ?
       WHERE id = ? AND user_id = ?`,
      [name.trim(), walletBalance, id, req.user.id],
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Không tìm thấy ví",
      });
    }

    res.json({
      message: "Cập nhật ví thành công",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Lỗi server",
    });
  }
});

// XÓA VÍ
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await pool.query(
      `DELETE FROM wallets
       WHERE id = ? AND user_id = ?`,
      [id, req.user.id],
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Không tìm thấy ví",
      });
    }

    res.json({
      message: "Xóa ví thành công",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Không thể xóa ví",
    });
  }
});

module.exports = router;
