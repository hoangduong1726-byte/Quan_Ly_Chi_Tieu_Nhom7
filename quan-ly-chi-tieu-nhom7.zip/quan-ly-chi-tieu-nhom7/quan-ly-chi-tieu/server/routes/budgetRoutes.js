const express = require("express");
const pool = require("../config/db");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

router.use(authMiddleware);

router.get("/", async (req, res) => {
  try {
    const [budgets] = await pool.query(
      `SELECT
        b.id,
        b.category_id,
        b.amount,
        b.month,
        b.year,
        c.name AS category_name,
        c.icon AS category_icon,
        c.color AS category_color,

        COALESCE(
          (
            SELECT SUM(t.amount)
            FROM transactions t
            WHERE t.user_id = b.user_id
              AND t.category_id = b.category_id
              AND t.type = 'expense'
              AND MONTH(t.transaction_date) = b.month
              AND YEAR(t.transaction_date) = b.year
          ),
          0
        ) AS spent

       FROM budgets b

       JOIN categories c
         ON b.category_id = c.id

       WHERE b.user_id = ?

       ORDER BY b.year DESC, b.month DESC, b.id DESC`,
      [req.user.id],
    );

    res.json(budgets);
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Không thể lấy danh sách ngân sách",
    });
  }
});

router.post("/", async (req, res) => {
  try {
    const { category_id, amount, month, year } = req.body;

    if (!category_id || !amount || !month || !year) {
      return res.status(400).json({
        message: "Vui lòng nhập đầy đủ thông tin",
      });
    }

    if (Number(amount) <= 0) {
      return res.status(400).json({
        message: "Ngân sách phải lớn hơn 0",
      });
    }

    if (Number(month) < 1 || Number(month) > 12) {
      return res.status(400).json({
        message: "Tháng không hợp lệ",
      });
    }
    const [categories] = await pool.query(
      `SELECT id
       FROM categories
       WHERE id = ?
         AND user_id = ?
         AND type = 'expense'`,
      [category_id, req.user.id],
    );

    if (categories.length === 0) {
      return res.status(400).json({
        message: "Chỉ được đặt ngân sách cho danh mục chi",
      });
    }
    const [existing] = await pool.query(
      `SELECT id
       FROM budgets
       WHERE user_id = ?
         AND category_id = ?
         AND month = ?
         AND year = ?`,
      [req.user.id, category_id, month, year],
    );

    if (existing.length > 0) {
      return res.status(400).json({
        message: "Danh mục này đã có ngân sách trong tháng đã chọn",
      });
    }

    const [result] = await pool.query(
      `INSERT INTO budgets
       (
         user_id,
         category_id,
         amount,
         month,
         year
       )
       VALUES (?, ?, ?, ?, ?)`,
      [req.user.id, category_id, Number(amount), Number(month), Number(year)],
    );

    res.status(201).json({
      message: "Thêm ngân sách thành công",
      id: result.insertId,
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Lỗi server",
    });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const { category_id, amount, month, year } = req.body;

    if (!category_id || !amount || !month || !year) {
      return res.status(400).json({
        message: "Vui lòng nhập đầy đủ thông tin",
      });
    }

    if (Number(amount) <= 0) {
      return res.status(400).json({
        message: "Ngân sách phải lớn hơn 0",
      });
    }

    if (Number(month) < 1 || Number(month) > 12) {
      return res.status(400).json({
        message: "Tháng không hợp lệ",
      });
    }

    const [categories] = await pool.query(
      `SELECT id
       FROM categories
       WHERE id = ?
         AND user_id = ?
         AND type = 'expense'`,
      [category_id, req.user.id],
    );

    if (categories.length === 0) {
      return res.status(400).json({
        message: "Chỉ được đặt ngân sách cho danh mục chi",
      });
    }

    const [existing] = await pool.query(
      `SELECT id
       FROM budgets
       WHERE user_id = ?
         AND category_id = ?
         AND month = ?
         AND year = ?
         AND id <> ?`,
      [req.user.id, category_id, month, year, id],
    );

    if (existing.length > 0) {
      return res.status(400).json({
        message: "Danh mục này đã có ngân sách trong tháng đã chọn",
      });
    }

    const [result] = await pool.query(
      `UPDATE budgets

       SET category_id = ?,
           amount = ?,
           month = ?,
           year = ?

       WHERE id = ?
         AND user_id = ?`,
      [
        category_id,
        Number(amount),
        Number(month),
        Number(year),
        id,
        req.user.id,
      ],
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Không tìm thấy ngân sách",
      });
    }

    res.json({
      message: "Cập nhật ngân sách thành công",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Lỗi server",
    });
  }
});
// XÓA NGÂN SÁCH
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await pool.query(
      `DELETE FROM budgets
       WHERE id = ?
         AND user_id = ?`,
      [id, req.user.id],
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Không tìm thấy ngân sách",
      });
    }

    res.json({
      message: "Xóa ngân sách thành công",
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Không thể xóa ngân sách",
    });
  }
});

module.exports = router;
