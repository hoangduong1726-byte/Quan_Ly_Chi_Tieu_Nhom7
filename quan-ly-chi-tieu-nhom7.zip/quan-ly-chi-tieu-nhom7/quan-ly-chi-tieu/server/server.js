const express = require("express");
const cors = require("cors");
require("dotenv").config();

const pool = require("./config/db");

const authRoutes = require("./routes/authRoutes");
const categoryRoutes = require("./routes/categoryRoutes");
const walletRoutes = require("./routes/walletRoutes");
const transactionRoutes = require("./routes/transactionRoutes");
const budgetRoutes = require("./routes/budgetRoutes");
const reportRoutes = require("./routes/reportRoutes");

const app = express();

app.use(cors());

app.use(
  express.json({
    limit: "5mb",
  })
);

app.use("/api/auth", authRoutes);

app.use(
  "/api/categories",
  categoryRoutes
);

app.use(
  "/api/wallets",
  walletRoutes
);

app.use(
  "/api/transactions",
  transactionRoutes
);

app.use(
  "/api/budgets",
  budgetRoutes
);

app.use(
  "/api/reports",
  reportRoutes
);

app.get("/", (req, res) => {
  res.json({
    message:
      "API Quản lý chi tiêu đang hoạt động",
  });
});

app.get("/api/test-db", async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SHOW TABLES"
    );

    res.json({
      message:
        "Kết nối MySQL thành công",
      tables: rows,
    });

  } catch (error) {
    console.error(
      "Lỗi MySQL:",
      error
    );

    res.status(500).json({
      message:
        "Không kết nối được MySQL",
      error: error.message,
    });
  }
});

// SERVER
const PORT =
  process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(
    `Server đang chạy tại http://localhost:${PORT}`
  );
});