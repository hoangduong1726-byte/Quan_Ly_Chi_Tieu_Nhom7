import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import { createTransaction } from "../services/transactionService";
import { getCategories } from "../services/categoryService";
import { getWallets } from "../services/walletService";

function AddTransaction() {
    const navigate = useNavigate();

    const [categories, setCategories] = useState([]);
    const [wallets, setWallets] = useState([]);

    const [formData, setFormData] = useState({
        type: "expense",
        amount: "",
        category_id: "",
        wallet_id: "",
        transaction_date: "",
        note: "",
    });

    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState("");
    const [message, setMessage] = useState("");

    useEffect(() => {
        const fetchData = async () => {
            try {
                setLoading(true);
                setError("");

                const [categoryData, walletData] =
                    await Promise.all([
                        getCategories(),
                        getWallets(),
                    ]);

                setCategories(categoryData);
                setWallets(walletData);
            } catch (err) {
                setError(
                    err.response?.data?.message ||
                    "Không thể tải dữ liệu"
                );
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    const filteredCategories = categories.filter(
        (category) => category.type === formData.type
    );
    const handleChange = (e) => {
        const { name, value } = e.target;

        if (name === "type") {
            setFormData({
                ...formData,
                type: value,
                category_id: "",
            });

            return;
        }

        setFormData({
            ...formData,
            [name]: value,
        });
    };
    const handleSubmit = async (e) => {
        e.preventDefault();

        setError("");
        setMessage("");

        if (
            !formData.amount ||
            !formData.category_id ||
            !formData.wallet_id ||
            !formData.transaction_date
        ) {
            setError("Vui lòng nhập đầy đủ thông tin");
            return;
        }

        if (Number(formData.amount) <= 0) {
            setError("Số tiền phải lớn hơn 0");
            return;
        }

        try {
            setSubmitting(true);

            await createTransaction(formData);

            setMessage("Thêm giao dịch thành công");

            setTimeout(() => {
                navigate("/transactions");
            }, 1000);
        } catch (err) {
            setError(
                err.response?.data?.message ||
                "Không thể thêm giao dịch"
            );
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="sample-page add-transaction-page">
            <div className="sample-page-header">
                <div>
                    <h1>Thêm giao dịch</h1>

                    <p>
                        Ghi lại khoản thu hoặc chi mới của bạn
                    </p>
                </div>
            </div>
            {error && (
                <div className="error-message">
                    {error}
                </div>
            )}

            {message && (
                <div className="success-message">
                    {message}
                </div>
            )}

            {loading ? (
                <div className="sample-card">
                    <p className="sample-state">
                        Đang tải dữ liệu...
                    </p>
                </div>
            ) : (
                <section className="sample-card add-transaction-card">
                    <div className="add-transaction-card-header">
                        <div>
                            <h2>Thông tin giao dịch</h2>

                        </div>

                        <Link
                            to="/transactions"
                            className="add-transaction-back"
                        >
                            ← Quay lại
                        </Link>
                    </div>

                    <form
                        className="add-transaction-form"
                        onSubmit={handleSubmit}
                    >
                        <div className="add-transaction-grid">
                            <div className="sample-form-group">
                                <label>Loại giao dịch</label>

                                <select
                                    name="type"
                                    value={formData.type}
                                    onChange={handleChange}
                                >
                                    <option value="expense">
                                        Chi tiêu
                                    </option>

                                    <option value="income">
                                        Thu nhập
                                    </option>
                                </select>
                            </div>
                            <div className="sample-form-group">
                                <label>Số tiền</label>

                                <input
                                    type="number"
                                    name="amount"
                                    min="1"
                                    placeholder="Nhập số tiền"
                                    value={formData.amount}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className="sample-form-group">
                                <label>Danh mục</label>

                                <select
                                    name="category_id"
                                    value={formData.category_id}
                                    onChange={handleChange}
                                >
                                    <option value="">
                                        -- Chọn danh mục --
                                    </option>

                                    {filteredCategories.map(
                                        (category) => (
                                            <option
                                                key={category.id}
                                                value={category.id}
                                            >
                                                {category.icon}{" "}
                                                {category.name}
                                            </option>
                                        )
                                    )}
                                </select>

                                {filteredCategories.length === 0 && (
                                    <p className="add-form-help error-help">
                                        Chưa có danh mục phù hợp với loại
                                        giao dịch này.
                                    </p>
                                )}
                            </div>
                            <div className="sample-form-group">
                                <label>Ví / tài khoản</label>

                                <select
                                    name="wallet_id"
                                    value={formData.wallet_id}
                                    onChange={handleChange}
                                >
                                    <option value="">
                                        -- Chọn ví --
                                    </option>

                                    {wallets.map((wallet) => (
                                        <option
                                            key={wallet.id}
                                            value={wallet.id}
                                        >
                                            {wallet.name}
                                        </option>
                                    ))}
                                </select>

                                {wallets.length === 0 && (
                                    <p className="add-form-help error-help">
                                        Chưa có ví. Hãy tạo ví trước khi
                                        thêm giao dịch.
                                    </p>
                                )}
                            </div>
                            <div className="sample-form-group">
                                <label>Ngày giao dịch</label>

                                <input
                                    type="date"
                                    name="transaction_date"
                                    value={formData.transaction_date}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="sample-form-group">
                                <label>Ghi chú</label>

                                <input
                                    type="text"
                                    name="note"
                                    value={formData.note}
                                    onChange={handleChange}
                                />
                            </div>
                        </div>
                        <div className="add-transaction-actions">
                            <Link
                                to="/transactions"
                                className="add-cancel-btn"
                            >
                                Hủy
                            </Link>

                            <button
                                type="submit"
                                className="add-submit-btn"
                                disabled={submitting}
                            >
                                {submitting
                                    ? "Đang thêm..."
                                    : "+ Thêm giao dịch"}
                            </button>
                        </div>
                    </form>
                </section>
            )}
        </div>
    );
}

export default AddTransaction;