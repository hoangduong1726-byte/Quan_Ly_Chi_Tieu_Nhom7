import { useEffect, useState } from "react";
import axios from "axios";
import { Camera, User } from "lucide-react";
import useLocalStorage from "../hooks/useLocalStorage";

function Profile() {
    const [user, setUser] = useLocalStorage(
        "user",
        null
    );

    const [formData, setFormData] = useState({
        name: "",
        email: "",
        birth_date: "",
        gender: "",
        avatar: "",
    });

    const [loading, setLoading] =
        useState(true);

    const [saving, setSaving] =
        useState(false);

    const [message, setMessage] =
        useState("");

    const [error, setError] =
        useState("");

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                setLoading(true);

                const token =
                    localStorage.getItem("token");

                const response =
                    await axios.get(
                        "http://localhost:5000/api/auth/me",
                        {
                            headers: {
                                Authorization:
                                    `Bearer ${token}`,
                            },
                        }
                    );

                const profile =
                    response.data.user;

                setFormData({
                    name: profile.name || "",
                    email: profile.email || "",

                    birth_date:
                        profile.birth_date
                            ? profile.birth_date
                                .toString()
                                .slice(0, 10)
                            : "",

                    gender:
                        profile.gender || "",

                    avatar:
                        profile.avatar || "",
                });

            } catch (err) {
                setError(
                    err.response?.data?.message ||
                    "Không thể tải hồ sơ"
                );
            } finally {
                setLoading(false);
            }
        };

        fetchProfile();
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;

        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    const handleAvatarChange = (e) => {
        const file = e.target.files?.[0];

        if (!file) return;

        if (!file.type.startsWith("image/")) {
            setError(
                "Vui lòng chọn một file ảnh"
            );
            return;
        }

        if (file.size > 2 * 1024 * 1024) {
            setError(
                "Ảnh đại diện không được vượt quá 2MB"
            );
            return;
        }

        const reader = new FileReader();

        reader.onloadend = () => {
            setFormData((prev) => ({
                ...prev,
                avatar: reader.result,
            }));

            setError("");
        };

        reader.readAsDataURL(file);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            setSaving(true);
            setError("");
            setMessage("");

            const token =
                localStorage.getItem("token");

            const response =
                await axios.put(
                    "http://localhost:5000/api/auth/profile",
                    {
                        name: formData.name,
                        birth_date:
                            formData.birth_date,
                        gender:
                            formData.gender,
                        avatar:
                            formData.avatar,
                    },
                    {
                        headers: {
                            Authorization:
                                `Bearer ${token}`,
                        },
                    }
                );

            const updatedUser =
                response.data.user;

            setUser(updatedUser);

            setMessage(
                "Cập nhật hồ sơ thành công"
            );

        } catch (err) {
            setError(
                err.response?.data?.message ||
                "Không thể cập nhật hồ sơ"
            );
        } finally {
            setSaving(false);
        }
    };


    const getInitial = () => {
        if (!formData.name) return "U";

        return formData.name
            .trim()
            .charAt(0)
            .toUpperCase();
    };


    if (loading) {
        return (
            <div className="profile-page">
                <p>Đang tải hồ sơ...</p>
            </div>
        );
    }


    return (
        <div className="profile-page">
            <div className="profile-heading">
                <h1>Hồ sơ cá nhân</h1>

                <p>
                    Quản lý thông tin cá nhân
                    của bạn
                </p>
            </div>

            <div className="profile-card">
                <form onSubmit={handleSubmit}>

                    <div className="profile-avatar-section">

                        <div className="profile-avatar">
                            {formData.avatar ? (
                                <img
                                    src={
                                        formData.avatar
                                    }
                                    alt="Ảnh đại diện"
                                />
                            ) : (
                                <span>
                                    {getInitial()}
                                </span>
                            )}
                        </div>

                        <div>
                            <h3>Ảnh đại diện</h3>

                            <p>
                                JPG, PNG tối đa 2MB
                            </p>

                            <label className="profile-upload-btn">
                                <Camera size={17} />

                                Đổi ảnh

                                <input
                                    type="file"
                                    accept="image/*"
                                    onChange={
                                        handleAvatarChange
                                    }
                                    hidden
                                />
                            </label>
                        </div>
                    </div>


                    <div className="profile-divider" />


                    {error && (
                        <div className="profile-error">
                            {error}
                        </div>
                    )}

                    {message && (
                        <div className="profile-success">
                            {message}
                        </div>
                    )}


                    <div className="profile-form-grid">

                        <div className="profile-field">
                            <label>
                                Họ và tên
                            </label>

                            <input
                                type="text"
                                name="name"
                                value={
                                    formData.name
                                }
                                onChange={
                                    handleChange
                                }
                                placeholder="Nhập họ và tên"
                            />
                        </div>


                        <div className="profile-field">
                            <label>Email</label>

                            <input
                                type="email"
                                value={
                                    formData.email
                                }
                                disabled
                            />

                            <small>
                                Email đăng nhập
                                không thể thay đổi
                            </small>
                        </div>


                        <div className="profile-field">
                            <label>
                                Ngày sinh
                            </label>

                            <input
                                type="date"
                                name="birth_date"
                                value={
                                    formData.birth_date
                                }
                                onChange={
                                    handleChange
                                }
                            />
                        </div>


                        <div className="profile-field">
                            <label>
                                Giới tính
                            </label>

                            <select
                                name="gender"
                                value={
                                    formData.gender
                                }
                                onChange={
                                    handleChange
                                }
                            >
                                <option value="">
                                    Chọn giới tính
                                </option>

                                <option value="Nam">
                                    Nam
                                </option>

                                <option value="Nữ">
                                    Nữ
                                </option>

                                <option value="Khác">
                                    Khác
                                </option>
                            </select>
                        </div>

                    </div>


                    <div className="profile-actions">
                        <button
                            type="submit"
                            disabled={saving}
                        >
                            <User size={17} />

                            {saving
                                ? "Đang lưu..."
                                : "Lưu thay đổi"}
                        </button>
                    </div>

                </form>
            </div>
        </div>
    );
}

export default Profile;