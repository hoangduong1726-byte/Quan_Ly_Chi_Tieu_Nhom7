import { useEffect, useMemo, useState } from "react";
import useLocalStorage from "../hooks/useLocalStorage";

import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
} from "recharts";

import {
  getSummary,
  getExpenseByCategory,
  getMonthlyReport,
} from "../services/reportService";


function Dashboard() {
  const [user] = useLocalStorage("user", null);

  const now = new Date();

  const [selectedMonth, setSelectedMonth] =
    useState(now.getMonth() + 1);

  const [selectedYear, setSelectedYear] =
    useState(now.getFullYear());

  const [summary, setSummary] = useState({
    total_income: 0,
    total_expense: 0,
    balance: 0,
  });

  const [categoryData, setCategoryData] =
    useState([]);

  const [monthlyData, setMonthlyData] =
    useState([]);

  const [loading, setLoading] = useState(true);
  const [categoryLoading, setCategoryLoading] =
    useState(false);

  const [error, setError] = useState("");
  useEffect(() => {
    const fetchMainData = async () => {
      try {
        setLoading(true);
        setError("");

        const [
          summaryData,
          monthlyReport,
        ] = await Promise.all([
          getSummary(
            selectedMonth,
            selectedYear
          ),
          getMonthlyReport(),
        ]);

        setSummary(summaryData);
        const fullYearData = Array.from(
          { length: 12 },
          (_, index) => {
            const month = index + 1;
            const found = monthlyReport.find(
              (item) =>
                Number(item.month) === month &&
                Number(item.year) === selectedYear
            );

            return {
              month,
              year: selectedYear,
              name: `T${month}`,

              income: found
                ? Number(found.income)
                : 0,

              expense: found
                ? Number(found.expense)
                : 0,
            };
          }
        );

        setMonthlyData(fullYearData);
      } catch (err) {
        console.error(err);

        setError(
          err.response?.data?.message ||
          "Không thể tải dữ liệu báo cáo"
        );
      } finally {
        setLoading(false);
      }
    };

    fetchMainData();
  }, [selectedMonth, selectedYear]);

  useEffect(() => {
    const fetchCategoryData = async () => {
      try {
        setCategoryLoading(true);
        setError("");

        const expenseData =
          await getExpenseByCategory(
            selectedMonth,
            selectedYear
          );

        setCategoryData(
          expenseData.map((item) => ({
            ...item,
            total: Number(item.total),
          }))
        );
      } catch (err) {
        console.error(err);

        setError(
          err.response?.data?.message ||
          "Không thể tải chi tiêu theo danh mục"
        );
      } finally {
        setCategoryLoading(false);
      }
    };

    fetchCategoryData();
  }, [selectedMonth, selectedYear]);

  const formatMoney = (amount) => {
    return (
      Number(amount || 0).toLocaleString("vi-VN") +
      " ₫"
    );
  };

  const formatShortMoney = (value) => {
    const number = Number(value || 0);

    if (number >= 1000000000) {
      return `${(
        number / 1000000000
      ).toFixed(1)} tỷ`;
    }

    if (number >= 1000000) {
      const valueInMillion =
        number / 1000000;

      return Number.isInteger(valueInMillion)
        ? `${valueInMillion}tr`
        : `${valueInMillion.toFixed(1)}tr`;
    }

    if (number >= 1000) {
      return `${number / 1000}k`;
    }

    return number;
  };

  const totalCategoryExpense = useMemo(() => {
    return categoryData.reduce(
      (total, item) =>
        total + Number(item.total || 0),
      0
    );
  }, [categoryData]);

  const getPercent = (value) => {
    if (totalCategoryExpense === 0) {
      return 0;
    }

    return (
      (Number(value || 0) /
        totalCategoryExpense) *
      100
    );
  };

  const yearOptions = useMemo(() => {
    const currentYear = now.getFullYear();

    const years = [];

    for (let year = currentYear; year >= 2024; year--) {
      years.push(year);
    }

    return years;
  }, []);


  return (
    <div className="home-dashboard">

      <div className="home-welcome">
        <h1>
          Xin chào,{" "}
          {user?.name || "Người dùng"} 
        </h1>

        <p>
          Cùng theo dõi tình hình tài chính của
          bạn hôm nay!
        </p>
      </div>


      {error && (
        <div className="error-message">
          {error}
        </div>
      )}


      {loading ? (
        <div className="home-loading">
          Đang tải dữ liệu...
        </div>
      ) : (
        <>
          <div className="home-summary">
            <div className="home-summary-card">
              <div className="home-summary-title">

                <span className="home-summary-icon income-bg">
                  ↑
                </span>

                <span>Tổng thu</span>

              </div>

              <strong className="home-income">
                {formatMoney(
                  summary.total_income
                )}
              </strong>

              <small className="positive-text">
                ↑ Tổng thu nhập đã ghi nhận
              </small>
            </div>
            <div className="home-summary-card">
              <div className="home-summary-title">

                <span className="home-summary-icon expense-bg">
                  ↓
                </span>

                <span>Tổng chi</span>

              </div>

              <strong className="home-expense">
                {formatMoney(
                  summary.total_expense
                )}
              </strong>

              <small className="negative-text">
                ↓ Tổng chi tiêu đã ghi nhận
              </small>
            </div>

            <div className="home-summary-card">
              <div className="home-summary-title">

                <span className="home-summary-icon balance-bg">
                  ₫
                </span>

                <span>Số dư</span>

              </div>

              <strong className="home-balance">
                {formatMoney(summary.balance)}
              </strong>

              <small>
                Tổng thu - chi
              </small>
            </div>

          </div>


          <div className="home-charts">
            <section className="home-chart-card dashboard-category-card">
              <div className="dashboard-chart-header">

                <div>
                  <h2>
                    Chi tiêu theo danh mục
                  </h2>

                  <p>
                    Phân bổ chi tiêu trong tháng
                  </p>
                </div>

                <div className="dashboard-month-filter">

                  <select
                    value={selectedMonth}
                    onChange={(e) =>
                      setSelectedMonth(
                        Number(e.target.value)
                      )
                    }
                  >
                    {Array.from(
                      { length: 12 },
                      (_, index) => index + 1
                    ).map((month) => (
                      <option
                        key={month}
                        value={month}
                      >
                        Tháng {month}
                      </option>
                    ))}
                  </select>


                  <select
                    value={selectedYear}
                    onChange={(e) =>
                      setSelectedYear(
                        Number(e.target.value)
                      )
                    }
                  >
                    {yearOptions.map((year) => (
                      <option
                        key={year}
                        value={year}
                      >
                        {year}
                      </option>
                    ))}
                  </select>

                </div>
              </div>


              {categoryLoading ? (
                <div className="home-empty">
                  Đang tải dữ liệu tháng...
                </div>
              ) : categoryData.length === 0 ? (
                <div className="home-empty">
                  Không có chi tiêu trong tháng{" "}
                  {selectedMonth}/{selectedYear}.
                </div>
              ) : (

                <div className="category-chart-layout">

                  <div className="category-donut">

                    <ResponsiveContainer
                      width="100%"
                      height="100%"
                    >
                      <PieChart>

                        <Pie
                          data={categoryData}
                          dataKey="total"
                          nameKey="name"

                          cx="50%"
                          cy="50%"

                          innerRadius={76}
                          outerRadius={116}

                          startAngle={90}
                          endAngle={-270}

                          paddingAngle={3}
                          cornerRadius={7}

                          stroke="#ffffff"
                          strokeWidth={3}
                        >

                          {categoryData.map(
                            (item, index) => (
                              <Cell
                                key={
                                  item.id ||
                                  index
                                }
                                fill={
                                  item.color ||
                                  "#1685f8"
                                }
                              />
                            )
                          )}

                        </Pie>


                        <Tooltip
                          formatter={(
                            value,
                            name
                          ) => [
                              formatMoney(value),
                              name,
                            ]}
                          contentStyle={{
                            borderRadius:
                              "12px",

                            border:
                              "1px solid #e2e8f0",

                            boxShadow:
                              "0 8px 24px rgba(15,23,42,0.10)",
                          }}
                        />

                      </PieChart>
                    </ResponsiveContainer>
                    <div className="donut-center">

                      <span>
                        Tổng chi
                      </span>

                      <strong>
                        {formatMoney(
                          totalCategoryExpense
                        )}
                      </strong>

                      <small>
                        Tháng {selectedMonth}
                      </small>

                    </div>

                  </div>

                  <div className="category-chart-list">

                    {categoryData.map(
                      (item, index) => {

                        const percent =
                          getPercent(
                            item.total
                          );

                        return (
                          <div
                            className="category-chart-item"
                            key={
                              item.id ||
                              index
                            }
                          >

                            <div className="category-item-top">
                              <div className="category-item-name">

                                <span
                                  className="category-dot"
                                  style={{
                                    backgroundColor:
                                      item.color ||
                                      "#1685f8",
                                  }}
                                />

                                <span className="category-icon">
                                  {item.icon ||
                                    "💰"}
                                </span>

                                <strong>
                                  {item.name}
                                </strong>

                              </div>

                              <div className="category-item-money">

                                <strong>
                                  {formatMoney(
                                    item.total
                                  )}
                                </strong>

                                <span>
                                  {percent.toFixed(
                                    0
                                  )}
                                  %
                                </span>

                              </div>

                            </div>


                            <div className="category-progress">

                              <div
                                className="category-progress-bar"
                                style={{
                                  width: `${Math.min(
                                    percent,
                                    100
                                  )}%`,

                                  backgroundColor:
                                    item.color ||
                                    "#1685f8",
                                }}
                              />

                            </div>

                          </div>
                        );
                      }
                    )}

                  </div>

                </div>
              )}

            </section>

            <section className="home-chart-card dashboard-trend-card">

              <div className="dashboard-chart-header">

                <div>
                  <h2>
                    Xu hướng thu - chi
                  </h2>

                  <p>
                    So sánh thu nhập và chi tiêu
                    theo thời gian
                  </p>
                </div>

              </div>


              {monthlyData.length === 0 ? (
                <div className="home-empty">
                  Chưa có dữ liệu giao dịch.
                </div>
              ) : (

                <div className="trend-chart">

                  <ResponsiveContainer
                    width="100%"
                    height="100%"
                  >

                    <AreaChart
                      data={monthlyData}
                      margin={{
                        top: 20,
                        right: 20,
                        left: 5,
                        bottom: 5,
                      }}
                    >

                      {/* GRADIENT */}
                      <defs>

                        <linearGradient
                          id="incomeGradient"
                          x1="0"
                          y1="0"
                          x2="0"
                          y2="1"
                        >

                          <stop
                            offset="5%"
                            stopColor="#10b981"
                            stopOpacity={0.3}
                          />

                          <stop
                            offset="95%"
                            stopColor="#10b981"
                            stopOpacity={0}
                          />

                        </linearGradient>


                        <linearGradient
                          id="expenseGradient"
                          x1="0"
                          y1="0"
                          x2="0"
                          y2="1"
                        >

                          <stop
                            offset="5%"
                            stopColor="#ef4444"
                            stopOpacity={0.28}
                          />

                          <stop
                            offset="95%"
                            stopColor="#ef4444"
                            stopOpacity={0}
                          />

                        </linearGradient>

                      </defs>

                      <CartesianGrid
                        strokeDasharray="4 4"
                        vertical={false}
                        stroke="#e2e8f0"
                      />

                      <XAxis
                        dataKey="name"
                        tickLine={false}
                        axisLine={{
                          stroke: "#cbd5e1",
                        }}
                        tick={{
                          fill: "#64748b",
                          fontSize: 12,
                        }}
                      />

                      <YAxis
                        tickLine={false}
                        axisLine={false}
                        width={50}
                        tickFormatter={
                          formatShortMoney
                        }
                        tick={{
                          fill: "#64748b",
                          fontSize: 12,
                        }}
                      />

                      <Tooltip
                        formatter={(
                          value,
                          name
                        ) => [
                            formatMoney(value),
                            name,
                          ]}
                        contentStyle={{
                          borderRadius:
                            "12px",

                          border:
                            "1px solid #e2e8f0",

                          boxShadow:
                            "0 8px 24px rgba(15,23,42,0.10)",
                        }}
                      />

                      <Legend
                        verticalAlign="bottom"
                        iconType="circle"
                        iconSize={9}
                        wrapperStyle={{
                          fontSize: "13px",
                          paddingTop: "12px",
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="income"
                        name="Thu nhập"

                        stroke="#10b981"
                        strokeWidth={3}

                        fill="url(#incomeGradient)"

                        dot={{
                          r: 4,
                          fill: "#10b981",
                          stroke: "#ffffff",
                          strokeWidth: 2,
                        }}

                        activeDot={{
                          r: 6,
                          stroke: "#ffffff",
                          strokeWidth: 3,
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="expense"
                        name="Chi tiêu"

                        stroke="#ef4444"
                        strokeWidth={3}

                        fill="url(#expenseGradient)"

                        dot={{
                          r: 4,
                          fill: "#ef4444",
                          stroke: "#ffffff",
                          strokeWidth: 2,
                        }}

                        activeDot={{
                          r: 6,
                          stroke: "#ffffff",
                          strokeWidth: 3,
                        }}
                      />

                    </AreaChart>

                  </ResponsiveContainer>

                </div>
              )}

            </section>

          </div>
        </>
      )}
    </div>
  );
}

export default Dashboard;