import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";

import {
  getTransactions,
  deleteTransaction,
} from "../services/transactionService";

import { getCategories } from "../services/categoryService";

function Transactions() {
  const [transactions, setTransactions] = useState([]);
  const [categories, setCategories] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const [filters, setFilters] = useState({
    keyword: "",
    type: "all",
    category_id: "all",
    fromDate: "",
    toDate: "",
    minAmount: "",
    maxAmount: "",
  });

  const fetchData = async () => {
    try {
      setLoading(true);
      setError("");

      const [transactionData, categoryData] =
        await Promise.all([
          getTransactions(),
          getCategories(),
        ]);

      setTransactions(transactionData);
      setCategories(categoryData);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Không thể tải dữ liệu"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleDelete = async (id) => {
    const confirmed = window.confirm(
      "Bạn có chắc muốn xóa giao dịch này?"
    );

    if (!confirmed) return;

    try {
      setError("");
      setMessage("");

      await deleteTransaction(id);

      setMessage("Xóa giao dịch thành công");

      await fetchData();
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Không thể xóa giao dịch"
      );
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;

    setFilters({
      ...filters,
      [name]: value,
    });
  };

  const resetFilters = () => {
    setFilters({
      keyword: "",
      type: "all",
      category_id: "all",
      fromDate: "",
      toDate: "",
      minAmount: "",
      maxAmount: "",
    });

    setError("");
    setMessage("");
  };

  const filteredTransactions = useMemo(() => {
    return transactions.filter((transaction) => {
      const matchKeyword =
        !filters.keyword ||
        (transaction.note || "")
          .toLowerCase()
          .includes(filters.keyword.toLowerCase());

      const matchType =
        filters.type === "all" ||
        transaction.type === filters.type;

      const matchCategory =
        filters.category_id === "all" ||
        String(transaction.category_id) ===
        String(filters.category_id);

      const transactionDate =
        transaction.transaction_date
          ? String(transaction.transaction_date).slice(
            0,
            10
          )
          : "";

      const matchFromDate =
        !filters.fromDate ||
        transactionDate >= filters.fromDate;

      const matchToDate =
        !filters.toDate ||
        transactionDate <= filters.toDate;

      const amount = Number(transaction.amount);

      const matchMinAmount =
        filters.minAmount === "" ||
        amount >= Number(filters.minAmount);

      const matchMaxAmount =
        filters.maxAmount === "" ||
        amount <= Number(filters.maxAmount);

      return (
        matchKeyword &&
        matchType &&
        matchCategory &&
        matchFromDate &&
        matchToDate &&
        matchMinAmount &&
        matchMaxAmount
      );
    });
  }, [transactions, filters]);

  const formatMoney = (amount) => {
    return Number(amount).toLocaleString("vi-VN") + " ₫";
  };

  const formatDate = (date) => {
    if (!date) return "";

    return new Date(date).toLocaleDateString("vi-VN");
  };

  const exportCSV = () => {
    if (filteredTransactions.length === 0) {
      setError("Không có giao dịch để xuất CSV");
      return;
    }

    const headers = [
      "Ngày",
      "Loại",
      "Danh mục",
      "Ví",
      "Ghi chú",
      "Số tiền",
    ];

    const rows = filteredTransactions.map(
      (transaction) => [
        formatDate(transaction.transaction_date),
        transaction.type === "income" ? "Thu" : "Chi",
        transaction.category_name || "",
        transaction.wallet_name || "",
        transaction.note || "",
        transaction.amount,
      ]
    );

    const escapeCSV = (value) => {
      const text = String(value ?? "").replace(
        /"/g,
        '""'
      );

      return `"${text}"`;
    };

    const csvContent = [
      headers.map(escapeCSV).join(","),
      ...rows.map((row) =>
        row.map(escapeCSV).join(",")
      ),
    ].join("\n");

    const blob = new Blob(
      ["\uFEFF" + csvContent],
      {
        type: "text/csv;charset=utf-8;",
      }
    );

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;

    link.download = `giao-dich-${new Date()
      .toISOString()
      .slice(0, 10)}.csv`;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(url);

    setError("");
    setMessage("Xuất CSV thành công");
  };

  return (
    <div className="sample-page transaction-page">
      <div className="sample-page-header transaction-page-header">
        <div>
          <h1>Quản lý giao dịch</h1>

          <p>
            Theo dõi và quản lý các khoản thu chi của bạn
          </p>
        </div>

        <Link
          to="/transactions/add"
          className="transaction-add-btn"
        >
          + Thêm giao dịch
        </Link>
      </div>

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      {message && (
        <div className="success-message">
          {message}
        </div>
      )}

      <section className="sample-card transaction-filter-card">
        <h2>Tìm kiếm và lọc</h2>

        <div className="transaction-filter-body">
          <div className="transaction-filter-grid">
            <div className="sample-form-group transaction-search">
              <label>Tìm theo ghi chú</label>

              <input
                type="text"
                name="keyword"
                placeholder="Nhập nội dung..."
                value={filters.keyword}
                onChange={handleFilterChange}
              />
            </div>

            <div className="sample-form-group">
              <label>Loại giao dịch</label>

              <select
                name="type"
                value={filters.type}
                onChange={handleFilterChange}
              >
                <option value="all">Tất cả</option>
                <option value="income">Thu</option>
                <option value="expense">Chi</option>
              </select>
            </div>

            <div className="sample-form-group">
              <label>Danh mục</label>

              <select
                name="category_id"
                value={filters.category_id}
                onChange={handleFilterChange}
              >
                <option value="all">
                  Tất cả danh mục
                </option>

                {categories.map((category) => (
                  <option
                    key={category.id}
                    value={category.id}
                  >
                    {category.icon} {category.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="sample-form-group">
              <label>Từ ngày</label>

              <input
                type="date"
                name="fromDate"
                value={filters.fromDate}
                onChange={handleFilterChange}
              />
            </div>

            <div className="sample-form-group">
              <label>Đến ngày</label>

              <input
                type="date"
                name="toDate"
                value={filters.toDate}
                onChange={handleFilterChange}
              />
            </div>

            <div className="sample-form-group">
              <label>Số tiền từ</label>

              <input
                type="number"
                name="minAmount"
                min="0"
                placeholder="0"
                value={filters.minAmount}
                onChange={handleFilterChange}
              />
            </div>

            <div className="sample-form-group">
              <label>Số tiền đến</label>

              <input
                type="number"
                name="maxAmount"
                min="0"
                placeholder="0"
                value={filters.maxAmount}
                onChange={handleFilterChange}
              />
            </div>
          </div>

          <div className="transaction-filter-actions">
            <button
              type="button"
              className="transaction-reset-btn"
              onClick={resetFilters}
            >
              Xóa bộ lọc
            </button>

            <button
              type="button"
              className="transaction-csv-btn"
              onClick={exportCSV}
            >
              Xuất CSV
            </button>
          </div>
        </div>
      </section>
      <section className="sample-card transaction-list-card">
        <div className="transaction-list-heading">
          <h2>Danh sách giao dịch</h2>

          {!loading && (
            <span>
              {filteredTransactions.length} giao dịch
            </span>
          )}
        </div>

        {loading ? (
          <p className="sample-state">
            Đang tải dữ liệu...
          </p>
        ) : filteredTransactions.length === 0 ? (
          <p className="sample-state">
            Không tìm thấy giao dịch phù hợp.
          </p>
        ) : (
          <div className="sample-table-wrapper">
            <table className="sample-table transaction-table">
              <thead>
                <tr>
                  <th>Ngày</th>
                  <th>Loại</th>
                  <th>Danh mục</th>
                  <th>Ví</th>
                  <th>Ghi chú</th>
                  <th>Số tiền</th>
                  <th>Thao tác</th>
                </tr>
              </thead>

              <tbody>
                {filteredTransactions.map(
                  (transaction) => (
                    <tr key={transaction.id}>
                      <td>
                        {formatDate(
                          transaction.transaction_date
                        )}
                      </td>

                      <td>
                        <span
                          className={
                            transaction.type === "income"
                              ? "sample-type income-type"
                              : "sample-type expense-type"
                          }
                        >
                          {transaction.type === "income"
                            ? "Thu"
                            : "Chi"}
                        </span>
                      </td>

                      <td>
                        <div className="transaction-category">
                          <span>
                            {transaction.category_icon ||
                              "💰"}
                          </span>

                          <strong>
                            {transaction.category_name ||
                              "-"}
                          </strong>
                        </div>
                      </td>

                      <td>
                        {transaction.wallet_name || "-"}
                      </td>

                      <td>
                        {transaction.note || "-"}
                      </td>

                      <td>
                        <strong
                          className={
                            transaction.type === "income"
                              ? "transaction-money income-money"
                              : "transaction-money expense-money"
                          }
                        >
                          {transaction.type === "income"
                            ? "+"
                            : "-"}
                          {formatMoney(
                            transaction.amount
                          )}
                        </strong>
                      </td>

                      <td>
                        <div className="sample-actions transaction-row-actions">
                          <Link
                            to={`/transactions/${transaction.id}`}
                            className="transaction-view-btn"
                          >
                            Xem
                          </Link>

                          <Link
                            to={`/transactions/${transaction.id}/edit`}
                            className="sample-edit-btn"
                          >
                            Sửa
                          </Link>

                          <button
                            type="button"
                            className="sample-delete-btn"
                            onClick={() =>
                              handleDelete(
                                transaction.id
                              )
                            }
                          >
                            Xóa
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

export default Transactions;