import { useEffect, useState } from "react";

import {
  getWallets,
  createWallet,
  updateWallet,
  deleteWallet,
} from "../services/walletService";

function Wallets() {
  const [wallets, setWallets] = useState([]);

  const [formData, setFormData] = useState({
    name: "",
    balance: "",
  });

  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const fetchWallets = async () => {
    try {
      setLoading(true);
      setError("");

      const data = await getWallets();
      setWallets(data);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Không thể tải danh sách ví"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWallets();
  }, []);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const resetForm = () => {
    setFormData({
      name: "",
      balance: "",
    });

    setEditingId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");
    setMessage("");

    if (!formData.name.trim()) {
      setError("Vui lòng nhập tên ví");
      return;
    }

    if (
      formData.balance !== "" &&
      Number(formData.balance) < 0
    ) {
      setError("Số dư không được âm");
      return;
    }

    try {
      const walletData = {
        name: formData.name,
        balance:
          formData.balance === ""
            ? 0
            : Number(formData.balance),
      };

      if (editingId) {
        await updateWallet(editingId, walletData);

        setMessage("Cập nhật ví thành công");
      } else {
        await createWallet(walletData);

        setMessage("Thêm ví thành công");
      }

      resetForm();
      await fetchWallets();
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Có lỗi xảy ra"
      );
    }
  };

  const handleEdit = (wallet) => {
    setEditingId(wallet.id);

    setFormData({
      name: wallet.name,
      balance: wallet.balance,
    });

    setMessage("");
    setError("");

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const handleDelete = async (id) => {
    const confirmed = window.confirm(
      "Bạn có chắc muốn xóa ví này?"
    );

    if (!confirmed) return;

    try {
      setError("");
      setMessage("");

      await deleteWallet(id);

      setMessage("Xóa ví thành công");

      await fetchWallets();
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Không thể xóa ví"
      );
    }
  };

  const formatMoney = (amount) => {
    return Number(amount).toLocaleString("vi-VN") + " ₫";
  };

  return (
    <div className="sample-page">
      {/* HEADER */}
      <div className="sample-page-header">
        <div>
          <h1>Quản lý ví / tài khoản</h1>
          <p>
            Tạo và quản lý các ví dùng để theo dõi thu chi
          </p>
        </div>
      </div>

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      {message && (
        <div className="success-message">
          {message}
        </div>
      )}

      <div className="wallet-sample-layout">
        <section className="sample-card wallet-small-form">
          <h2>
            {editingId ? "Sửa ví" : "Thêm ví"}
          </h2>

          <form onSubmit={handleSubmit}>
            <div className="sample-form-group">
              <label>Tên ví</label>

              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
              />
            </div>

            <div className="sample-form-group">
              <label>Số dư</label>

              <input
                type="number"
                name="balance"
                min="0"
                placeholder="0"
                value={formData.balance}
                onChange={handleChange}
              />
            </div>

            <button
              type="submit"
              className="sample-primary-btn"
            >
              {editingId
                ? "Lưu thay đổi"
                : "+ Thêm ví"}
            </button>

            {editingId && (
              <button
                type="button"
                className="sample-cancel-btn"
                onClick={resetForm}
              >
                Hủy
              </button>
            )}
          </form>
        </section>
        <section className="sample-card wallet-sample-list">
          <h2>Danh sách ví</h2>

          {loading ? (
            <p className="sample-state">
              Đang tải...
            </p>
          ) : wallets.length === 0 ? (
            <p className="sample-state">
              Chưa có ví nào.
            </p>
          ) : (
            <div className="sample-table-wrapper">
              <table className="sample-table">
                <thead>
                  <tr>
                    <th>Tên ví</th>
                    <th>Số dư</th>
                    <th>Thao tác</th>
                  </tr>
                </thead>

                <tbody>
                  {wallets.map((wallet) => (
                    <tr key={wallet.id}>
                      <td>
                        <div className="wallet-name">
                          <span className="wallet-icon">
                            💳
                          </span>

                          <strong>
                            {wallet.name}
                          </strong>
                        </div>
                      </td>

                      <td>
                        <strong className="wallet-balance">
                          {formatMoney(wallet.balance)}
                        </strong>
                      </td>

                      <td>
                        <div className="sample-actions">
                          <button
                            type="button"
                            className="sample-edit-btn"
                            onClick={() =>
                              handleEdit(wallet)
                            }
                          >
                            Sửa
                          </button>

                          <button
                            type="button"
                            className="sample-delete-btn"
                            onClick={() =>
                              handleDelete(wallet.id)
                            }
                          >
                            Xóa
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

export default Wallets;