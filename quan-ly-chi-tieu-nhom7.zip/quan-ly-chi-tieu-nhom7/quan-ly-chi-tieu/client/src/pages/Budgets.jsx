import { useEffect, useState } from "react";

import {
  getBudgets,
  createBudget,
  updateBudget,
  deleteBudget,
} from "../services/budgetService";

import { getCategories } from "../services/categoryService";

function Budgets() {
  const currentDate = new Date();

  const [budgets, setBudgets] = useState([]);
  const [categories, setCategories] = useState([]);

  const [formData, setFormData] = useState({
    category_id: "",
    amount: "",
    month: currentDate.getMonth() + 1,
    year: currentDate.getFullYear(),
  });

  const [editingId, setEditingId] = useState(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");


  const fetchData = async () => {
    try {
      setLoading(true);
      setError("");

      const [budgetData, categoryData] =
        await Promise.all([
          getBudgets(),
          getCategories(),
        ]);

      setBudgets(budgetData);

      setCategories(
        categoryData.filter(
          (category) => category.type === "expense"
        )
      );
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Không thể tải dữ liệu"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);


  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

 
  const resetForm = () => {
    setFormData({
      category_id: "",
      amount: "",
      month: currentDate.getMonth() + 1,
      year: currentDate.getFullYear(),
    });

    setEditingId(null);
  };

 
  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");
    setMessage("");

    if (
      !formData.category_id ||
      !formData.amount ||
      !formData.month ||
      !formData.year
    ) {
      setError("Vui lòng nhập đầy đủ thông tin");
      return;
    }

    if (Number(formData.amount) <= 0) {
      setError("Ngân sách phải lớn hơn 0");
      return;
    }

    try {
      if (editingId) {
        await updateBudget(editingId, formData);

        setMessage(
          "Cập nhật ngân sách thành công"
        );
      } else {
        await createBudget(formData);

        setMessage("Thêm ngân sách thành công");
      }

      resetForm();

      await fetchData();
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Có lỗi xảy ra"
      );
    }
  };

  const handleEdit = (budget) => {
    setEditingId(budget.id);

    setFormData({
      category_id: String(budget.category_id),
      amount: budget.amount,
      month: budget.month,
      year: budget.year,
    });

    setError("");
    setMessage("");

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };


  const handleDelete = async (id) => {
    const confirmed = window.confirm(
      "Bạn có chắc muốn xóa ngân sách này?"
    );

    if (!confirmed) return;

    try {
      setError("");
      setMessage("");

      await deleteBudget(id);

      setMessage("Xóa ngân sách thành công");

      if (editingId === id) {
        resetForm();
      }

      await fetchData();
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Không thể xóa ngân sách"
      );
    }
  };
  const formatMoney = (amount) => {
    return (
      Number(amount).toLocaleString("vi-VN") + " ₫"
    );
  };
  const getBudgetStatus = (budget) => {
    const amount = Number(budget.amount);
    const spent = Number(budget.spent);

    const percentage =
      amount > 0 ? (spent / amount) * 100 : 0;

    if (percentage >= 100) {
      return {
        text: "Đã vượt",
        percentage,
        className: "budget-danger",
      };
    }

    if (percentage >= 80) {
      return {
        text: "Sắp vượt",
        percentage,
        className: "budget-warning",
      };
    }

    return {
      text: "Trong hạn mức",
      percentage,
      className: "budget-safe",
    };
  };

  return (
    <div className="sample-page budget-page">
      {/* HEADER */}
      <div className="sample-page-header">
        <div>
          <h1>Quản lý ngân sách</h1>

          <p>
            Theo dõi và kiểm soát giới hạn chi tiêu
            hàng tháng
          </p>
        </div>
      </div>
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      {message && (
        <div className="success-message">
          {message}
        </div>
      )}

      <div className="budget-layout">
        <section className="sample-card budget-form-card">
          <h2>
            {editingId
              ? "Sửa ngân sách"
              : "Đặt ngân sách"}
          </h2>

          <form onSubmit={handleSubmit}>
            <div className="sample-form-group">
              <label>Danh mục chi</label>

              <select
                name="category_id"
                value={formData.category_id}
                onChange={handleChange}
              >
                <option value="">
                  -- Chọn danh mục --
                </option>

                {categories.map((category) => (
                  <option
                    key={category.id}
                    value={category.id}
                  >
                    {category.icon} {category.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="sample-form-group">
              <label>Ngân sách</label>

              <input
                type="number"
                name="amount"
                min="1"
                value={formData.amount}
                onChange={handleChange}
              />
            </div>

            <div className="budget-date-grid">
              <div className="sample-form-group">
                <label>Tháng</label>

                <select
                  name="month"
                  value={formData.month}
                  onChange={handleChange}
                >
                  {Array.from(
                    { length: 12 },
                    (_, index) => index + 1
                  ).map((month) => (
                    <option
                      key={month}
                      value={month}
                    >
                      Tháng {month}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sample-form-group">
                <label>Năm</label>

                <input
                  type="number"
                  name="year"
                  min="2000"
                  max="2100"
                  value={formData.year}
                  onChange={handleChange}
                />
              </div>
            </div>

            <button
              type="submit"
              className="sample-primary-btn"
            >
              {editingId
                ? "Lưu thay đổi"
                : "+ Đặt ngân sách"}
            </button>

            {editingId && (
              <button
                type="button"
                className="sample-cancel-btn"
                onClick={resetForm}
              >
                Hủy
              </button>
            )}
          </form>
        </section>
        <section className="sample-card budget-list-card">
          <h2>Danh sách ngân sách</h2>

          {loading ? (
            <p className="sample-state">
              Đang tải...
            </p>
          ) : budgets.length === 0 ? (
            <p className="sample-state">
              Chưa có ngân sách nào.
            </p>
          ) : (
            <div className="sample-table-wrapper">
              <table className="sample-table budget-table">
                <thead>
                  <tr>
                    <th>Danh mục</th>
                    <th>Thời gian</th>
                    <th>Ngân sách</th>
                    <th>Đã chi</th>
                    <th>Còn lại</th>
                    <th>Tiến độ</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                  </tr>
                </thead>

                <tbody>
                  {budgets.map((budget) => {
                    const status =
                      getBudgetStatus(budget);

                    const remaining =
                      Number(budget.amount) -
                      Number(budget.spent);

                    const progressWidth = Math.min(
                      status.percentage,
                      100
                    );

                    return (
                      <tr key={budget.id}>
                        <td>
                          <div className="budget-category">
                            <span>
                              {budget.category_icon}
                            </span>

                            <strong>
                              {budget.category_name}
                            </strong>
                          </div>
                        </td>

                        <td>
                          Tháng {budget.month}/
                          {budget.year}
                        </td>

                        <td>
                          <strong>
                            {formatMoney(
                              budget.amount
                            )}
                          </strong>
                        </td>

                        <td>
                          {formatMoney(
                            budget.spent
                          )}
                        </td>

                        <td
                          className={
                            remaining < 0
                              ? "budget-negative"
                              : ""
                          }
                        >
                          {formatMoney(remaining)}
                        </td>

                        <td>
                          <div className="budget-progress-cell">
                            <div className="budget-progress">
                              <div
                                className={`budget-progress-bar ${status.className}`}
                                style={{
                                  width: `${progressWidth}%`,
                                }}
                              />
                            </div>

                            <span>
                              {status.percentage.toFixed(
                                1
                              )}
                              %
                            </span>
                          </div>
                        </td>

                        <td>
                          <span
                            className={`budget-status ${status.className}`}
                          >
                            {status.text}
                          </span>
                        </td>

                        <td>
                          <div className="sample-actions">
                            <button
                              type="button"
                              className="sample-edit-btn"
                              onClick={() =>
                                handleEdit(budget)
                              }
                            >
                              Sửa
                            </button>

                            <button
                              type="button"
                              className="sample-delete-btn"
                              onClick={() =>
                                handleDelete(
                                  budget.id
                                )
                              }
                            >
                              Xóa
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

export default Budgets;