import { useState } from "react";
import {
  Eye,
  EyeOff,
  Lock,
  Mail,
  User,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

function Register() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] =
    useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setMessage("");
    setError("");

    if (
      !formData.name ||
      !formData.email ||
      !formData.password ||
      !formData.confirmPassword
    ) {
      setError("Vui lòng nhập đầy đủ thông tin");
      return;
    }

    if (formData.password.length < 6) {
      setError("Mật khẩu phải có ít nhất 6 ký tự");
      return;
    }

    if (
      formData.password !== formData.confirmPassword
    ) {
      setError("Mật khẩu xác nhận không khớp");
      return;
    }

    try {
      setLoading(true);

      const response = await axios.post(
        "http://localhost:5000/api/auth/register",
        {
          name: formData.name,
          email: formData.email,
          password: formData.password,
        }
      );

      setMessage(
        response.data.message ||
        "Đăng ký tài khoản thành công"
      );

      setFormData({
        name: "",
        email: "",
        password: "",
        confirmPassword: "",
      });

      setTimeout(() => {
        navigate("/login");
      }, 1000);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Không thể kết nối đến server"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-circle login-circle-1"></div>
      <div className="login-circle login-circle-2"></div>
      <div className="login-circle login-circle-3"></div>

      <div className="login-card register-card">
        <div className="login-header">
          <h1>Đăng ký</h1>

          <p>
            Tạo tài khoản để bắt đầu quản lý thu chi và
            tài chính cá nhân.
          </p>
        </div>
        {error && (
          <div className="login-error">
            {error}
          </div>
        )}
        {message && (
          <div className="register-success">
            {message}
          </div>
        )}

        <form
          className="login-form"
          onSubmit={handleSubmit}
        >
          <div className="login-form-group">
            <label>Họ và tên</label>

            <div className="login-input">
              <User
                className="login-field-icon"
                size={18}
              />

              <input
                type="text"
                name="name"
                placeholder="Nhập họ và tên"
                value={formData.name}
                onChange={handleChange}
              />
            </div>
          </div>
          <div className="login-form-group">
            <label>Email</label>

            <div className="login-input">
              <Mail
                className="login-field-icon"
                size={18}
              />

              <input
                type="email"
                name="email"
                placeholder="Nhập email của bạn"
                value={formData.email}
                onChange={handleChange}
              />
            </div>
          </div>
          <div className="login-form-group">
            <label>Mật khẩu</label>

            <div className="login-input">
              <Lock
                className="login-field-icon"
                size={18}
              />

              <input
                type={
                  showPassword
                    ? "text"
                    : "password"
                }
                name="password"
                placeholder="Nhập mật khẩu"
                value={formData.password}
                onChange={handleChange}
              />

              <button
                type="button"
                className="login-eye-btn"
                onClick={() =>
                  setShowPassword(!showPassword)
                }
                aria-label={
                  showPassword
                    ? "Ẩn mật khẩu"
                    : "Hiện mật khẩu"
                }
              >
                {showPassword ? (
                  <EyeOff size={19} />
                ) : (
                  <Eye size={19} />
                )}
              </button>
            </div>
          </div>

          <div className="login-form-group">
            <label>Xác nhận mật khẩu</label>

            <div className="login-input">
              <Lock
                className="login-field-icon"
                size={18}
              />

              <input
                type={
                  showConfirmPassword
                    ? "text"
                    : "password"
                }
                name="confirmPassword"
                placeholder="Nhập lại mật khẩu"
                value={formData.confirmPassword}
                onChange={handleChange}
              />

              <button
                type="button"
                className="login-eye-btn"
                onClick={() =>
                  setShowConfirmPassword(
                    !showConfirmPassword
                  )
                }
                aria-label={
                  showConfirmPassword
                    ? "Ẩn mật khẩu"
                    : "Hiện mật khẩu"
                }
              >
                {showConfirmPassword ? (
                  <EyeOff size={19} />
                ) : (
                  <Eye size={19} />
                )}
              </button>
            </div>
          </div>
          <button
            type="submit"
            className="login-button"
            disabled={loading}
          >
            {loading
              ? "Đang đăng ký..."
              : "Đăng ký"}
          </button>
        </form>

        <div className="login-register">
          <span>Đã có tài khoản?</span>

          <Link to="/login">
            Đăng nhập ngay
          </Link>
        </div>
      </div>

      <div className="login-footer">
        Theo dõi thu chi • Quản lý ngân sách • Kiểm soát tài chính
      </div>
    </div>
  );
}

export default Register;