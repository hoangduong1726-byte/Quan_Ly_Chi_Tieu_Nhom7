import { useEffect, useState } from "react";

import {
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
} from "../services/categoryService";

function Categories() {
  const defaultForm = {
    name: "",
    type: "expense",
    icon: "💰",
    color: "#3498db",
  };

  const [categories, setCategories] = useState([]);
  const [formData, setFormData] = useState(defaultForm);
  const [editingId, setEditingId] = useState(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const fetchCategories = async () => {
    try {
      setLoading(true);
      setError("");

      const data = await getCategories();
      setCategories(data);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Không thể tải danh mục"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");
    setMessage("");

    if (!formData.name.trim()) {
      setError("Vui lòng nhập tên danh mục");
      return;
    }

    try {
      if (editingId) {
        await updateCategory(editingId, formData);
        setMessage("Cập nhật danh mục thành công");
      } else {
        await createCategory(formData);
        setMessage("Thêm danh mục thành công");
      }

      setFormData(defaultForm);
      setEditingId(null);

      await fetchCategories();
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Có lỗi xảy ra"
      );
    }
  };

  const handleEdit = (category) => {
    setEditingId(category.id);

    setFormData({
      name: category.name,
      type: category.type,
      icon: category.icon || "💰",
      color: category.color || "#3498db",
    });

    setError("");
    setMessage("");
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setFormData(defaultForm);
    setError("");
    setMessage("");
  };

  const handleDelete = async (id) => {
    const confirmed = window.confirm(
      "Bạn có chắc muốn xóa danh mục này?"
    );

    if (!confirmed) return;

    try {
      setError("");
      setMessage("");

      await deleteCategory(id);

      setMessage("Xóa danh mục thành công");

      await fetchCategories();
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Không thể xóa danh mục"
      );
    }
  };

  return (
    <div className="sample-page">
      <div className="sample-page-header">
        <div>
          <h1>Quản lý danh mục</h1>
          <p>Tạo và quản lý các danh mục thu và chi</p>
        </div>
      </div>

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
      {message && (
        <div className="success-message">
          {message}
        </div>
      )}

      <div className="category-sample-layout">
        <section className="sample-card category-small-form">
          <h2>
            {editingId
              ? "Sửa danh mục"
              : "Thêm danh mục"}
          </h2>

          <form onSubmit={handleSubmit}>
            <div className="sample-form-group">
              <label>Tên danh mục</label>

              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
              />
            </div>

            <div className="sample-form-group">
              <label>Loại</label>

              <select
                name="type"
                value={formData.type}
                onChange={handleChange}
              >
                <option value="expense">
                  Chi tiêu
                </option>

                <option value="income">
                  Thu nhập
                </option>
              </select>
            </div>

            <div className="sample-form-group">
              <label>Biểu tượng</label>

              <select
                name="icon"
                value={formData.icon}
                onChange={handleChange}
              >
                <option value="💰">💰 Tiền</option>
                <option value="🍜">🍜 Ăn uống</option>
                <option value="🛵">🛵 Đi lại</option>
                <option value="🛒">🛒 Mua sắm</option>
                <option value="🏠">🏠 Nhà ở</option>
                <option value="🎮">🎮 Giải trí</option>
                <option value="📚">📚 Học tập</option>
                <option value="💊">💊 Sức khỏe</option>
                <option value="💼">💼 Công việc</option>
                <option value="🎁">🎁 Quà tặng</option>
              </select>
            </div>

            <div className="sample-form-group">
              <label>Màu sắc</label>

              <div className="sample-color-input">
                <input
                  type="color"
                  name="color"
                  value={formData.color}
                  onChange={handleChange}
                  title="Chọn màu"
                />
              </div>
            </div>

            <button
              type="submit"
              className="sample-primary-btn"
            >
              {editingId
                ? "Lưu thay đổi"
                : "+ Thêm danh mục"}
            </button>

            {editingId && (
              <button
                type="button"
                className="sample-cancel-btn"
                onClick={handleCancelEdit}
              >
                Hủy
              </button>
            )}
          </form>
        </section>

        <section className="sample-card category-sample-list">
          <h2>Danh sách danh mục</h2>

          {loading ? (
            <p className="sample-state">
              Đang tải...
            </p>
          ) : categories.length === 0 ? (
            <p className="sample-state">
              Chưa có danh mục nào.
            </p>
          ) : (
            <div className="sample-table-wrapper">
              <table className="sample-table">
                <thead>
                  <tr>
                    <th>Icon</th>
                    <th>Tên danh mục</th>
                    <th>Loại</th>
                    <th>Màu sắc</th>
                    <th>Thao tác</th>
                  </tr>
                </thead>

                <tbody>
                  {categories.map((category) => (
                    <tr key={category.id}>
                      <td className="category-emoji">
                        {category.icon || "💰"}
                      </td>
                      <td>
                        <strong>
                          {category.name}
                        </strong>
                      </td>
                      <td>
                        <span
                          className={
                            category.type === "income"
                              ? "sample-type income-type"
                              : "sample-type expense-type"
                          }
                        >
                          {category.type === "income"
                            ? "Thu"
                            : "Chi"}
                        </span>
                      </td>
                      <td>
                        <div className="sample-color">
                          <span
                            title={category.color || "#3498db"}
                            style={{
                              backgroundColor:
                                category.color ||
                                "#3498db",
                            }}
                          />
                        </div>
                      </td>
                      <td>
                        <div className="sample-actions">
                          <button
                            type="button"
                            className="sample-edit-btn"
                            onClick={() =>
                              handleEdit(category)
                            }
                          >
                            Sửa
                          </button>

                          <button
                            type="button"
                            className="sample-delete-btn"
                            onClick={() =>
                              handleDelete(category.id)
                            }
                          >
                            Xóa
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

export default Categories;