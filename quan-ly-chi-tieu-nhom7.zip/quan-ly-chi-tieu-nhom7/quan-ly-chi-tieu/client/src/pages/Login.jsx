import { useState } from "react";
import { Eye, EyeOff, Lock, Mail } from "lucide-react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");

    if (!email || !password) {
      setError("Vui lòng nhập email và mật khẩu");
      return;
    }

    try {
      setLoading(true);

      const response = await axios.post(
        "http://localhost:5000/api/auth/login",
        {
          email,
          password,
        }
      );

      localStorage.setItem(
        "token",
        response.data.token
      );

      localStorage.setItem(
        "user",
        JSON.stringify(response.data.user)
      );

      navigate("/");
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Không thể kết nối đến server"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-circle login-circle-1"></div>
      <div className="login-circle login-circle-2"></div>
      <div className="login-circle login-circle-3"></div>

      <div className="login-card">
        <div className="login-header">
          <h1>Đăng nhập</h1>

          <p>
            Chào mừng bạn quay trở lại! Đăng nhập để
            tiếp tục quản lý tài chính.
          </p>
        </div>

        {error && (
          <div className="login-error">
            {error}
          </div>
        )}
        <form
          className="login-form"
          onSubmit={handleSubmit}
        >
          <div className="login-form-group">
            <label>Email</label>

            <div className="login-input">
              <Mail
                className="login-field-icon"
                size={18}
              />

              <input
                type="email"
                placeholder="Nhập email của bạn"
                value={email}
                onChange={(e) =>
                  setEmail(e.target.value)
                }
              />
            </div>
          </div>
          <div className="login-form-group">
            <label>Mật khẩu</label>

            <div className="login-input">
              <Lock
                className="login-field-icon"
                size={18}
              />

              <input
                type={
                  showPassword
                    ? "text"
                    : "password"
                }
                placeholder="Nhập mật khẩu"
                value={password}
                onChange={(e) =>
                  setPassword(e.target.value)
                }
              />

              <button
                type="button"
                className="login-eye-btn"
                onClick={() =>
                  setShowPassword(!showPassword)
                }
                aria-label={
                  showPassword
                    ? "Ẩn mật khẩu"
                    : "Hiện mật khẩu"
                }
              >
                {showPassword ? (
                  <EyeOff size={19} />
                ) : (
                  <Eye size={19} />
                )}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="login-button"
            disabled={loading}
          >
            {loading
              ? "Đang đăng nhập..."
              : "Đăng nhập"}
          </button>
        </form>

        <div className="login-register">
          <span>Chưa có tài khoản?</span>

          <Link to="/register">
            Đăng ký ngay
          </Link>
        </div>
      </div>

      <div className="login-footer">
        Theo dõi thu chi • Quản lý ngân sách • Kiểm soát tài chính
      </div>
    </div>
  );
}

export default Login;