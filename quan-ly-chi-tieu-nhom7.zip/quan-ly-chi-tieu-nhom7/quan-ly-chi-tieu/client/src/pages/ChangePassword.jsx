import { useState } from "react";
import axios from "axios";
import {
    Lock,
    Eye,
    EyeOff,
    KeyRound,
} from "lucide-react";

function ChangePassword() {
    const [formData, setFormData] = useState({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
    });

    const [showCurrent, setShowCurrent] =
        useState(false);

    const [showNew, setShowNew] =
        useState(false);

    const [showConfirm, setShowConfirm] =
        useState(false);

    const [loading, setLoading] =
        useState(false);

    const [error, setError] =
        useState("");

    const [message, setMessage] =
        useState("");

    const handleChange = (e) => {
        const { name, value } = e.target;

        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        setError("");
        setMessage("");

        if (
            !formData.currentPassword ||
            !formData.newPassword ||
            !formData.confirmPassword
        ) {
            setError(
                "Vui lòng nhập đầy đủ thông tin"
            );
            return;
        }

        if (formData.newPassword.length < 6) {
            setError(
                "Mật khẩu mới phải có ít nhất 6 ký tự"
            );
            return;
        }

        if (
            formData.newPassword !==
            formData.confirmPassword
        ) {
            setError(
                "Xác nhận mật khẩu không khớp"
            );
            return;
        }

        try {
            setLoading(true);

            const token =
                localStorage.getItem("token");

            const response = await axios.put(
                "http://localhost:5000/api/auth/change-password",
                formData,
                {
                    headers: {
                        Authorization:
                            `Bearer ${token}`,
                    },
                }
            );

            setMessage(response.data.message);

            // Xóa dữ liệu sau khi đổi thành công
            setFormData({
                currentPassword: "",
                newPassword: "",
                confirmPassword: "",
            });

        } catch (err) {
            setError(
                err.response?.data?.message ||
                "Không thể đổi mật khẩu"
            );

        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="change-password-page">

            <div className="change-password-heading">
                <h1>Đổi mật khẩu</h1>

                <p>
                    Cập nhật mật khẩu để bảo vệ
                    tài khoản của bạn
                </p>
            </div>


            <div className="change-password-card">

                <div className="change-password-icon">
                    <KeyRound size={26} />
                </div>

                <div className="change-password-title">
                    <h2>Thay đổi mật khẩu</h2>

                    <p>
                        Mật khẩu mới phải có ít nhất
                        6 ký tự
                    </p>
                </div>


                <form onSubmit={handleSubmit}>

                    {error && (
                        <div className="profile-error">
                            {error}
                        </div>
                    )}

                    {message && (
                        <div className="profile-success">
                            {message}
                        </div>
                    )}


                    {/* MẬT KHẨU HIỆN TẠI */}

                    <div className="password-field">
                        <label>
                            Mật khẩu hiện tại
                        </label>

                        <div className="password-input-wrapper">

                            <Lock size={18} />

                            <input
                                type={
                                    showCurrent
                                        ? "text"
                                        : "password"
                                }
                                name="currentPassword"
                                value={
                                    formData.currentPassword
                                }
                                onChange={handleChange}
                                placeholder="Nhập mật khẩu hiện tại"
                            />

                            <button
                                type="button"
                                onClick={() =>
                                    setShowCurrent(
                                        !showCurrent
                                    )
                                }
                            >
                                {showCurrent ? (
                                    <EyeOff size={18} />
                                ) : (
                                    <Eye size={18} />
                                )}
                            </button>

                        </div>
                    </div>


                    {/* MẬT KHẨU MỚI */}

                    <div className="password-field">
                        <label>
                            Mật khẩu mới
                        </label>

                        <div className="password-input-wrapper">

                            <Lock size={18} />

                            <input
                                type={
                                    showNew
                                        ? "text"
                                        : "password"
                                }
                                name="newPassword"
                                value={
                                    formData.newPassword
                                }
                                onChange={handleChange}
                                placeholder="Nhập mật khẩu mới"
                            />

                            <button
                                type="button"
                                onClick={() =>
                                    setShowNew(!showNew)
                                }
                            >
                                {showNew ? (
                                    <EyeOff size={18} />
                                ) : (
                                    <Eye size={18} />
                                )}
                            </button>

                        </div>
                    </div>


                    {/* XÁC NHẬN MẬT KHẨU */}

                    <div className="password-field">
                        <label>
                            Xác nhận mật khẩu mới
                        </label>

                        <div className="password-input-wrapper">

                            <Lock size={18} />

                            <input
                                type={
                                    showConfirm
                                        ? "text"
                                        : "password"
                                }
                                name="confirmPassword"
                                value={
                                    formData.confirmPassword
                                }
                                onChange={handleChange}
                                placeholder="Nhập lại mật khẩu mới"
                            />

                            <button
                                type="button"
                                onClick={() =>
                                    setShowConfirm(
                                        !showConfirm
                                    )
                                }
                            >
                                {showConfirm ? (
                                    <EyeOff size={18} />
                                ) : (
                                    <Eye size={18} />
                                )}
                            </button>

                        </div>
                    </div>


                    <button
                        type="submit"
                        className="change-password-btn"
                        disabled={loading}
                    >
                        <KeyRound size={18} />

                        {loading
                            ? "Đang cập nhật..."
                            : "Đổi mật khẩu"}
                    </button>

                </form>
            </div>
        </div>
    );
}

export default ChangePassword;