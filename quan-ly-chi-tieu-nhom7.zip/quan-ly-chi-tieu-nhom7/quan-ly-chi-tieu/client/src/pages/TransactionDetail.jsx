import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

import { getTransactionById } from "../services/transactionService";

function TransactionDetail() {
  const { id } = useParams();

  const [transaction, setTransaction] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchTransaction = async () => {
      try {
        setLoading(true);
        setError("");

        const data = await getTransactionById(id);

        setTransaction(data);
      } catch (err) {
        setError(
          err.response?.data?.message ||
          "Không thể tải giao dịch"
        );
      } finally {
        setLoading(false);
      }
    };

    fetchTransaction();
  }, [id]);

  const formatMoney = (amount) => {
    return Number(amount).toLocaleString("vi-VN") + " ₫";
  };

  const formatDate = (date) => {
    if (!date) return "-";

    return new Date(date).toLocaleDateString("vi-VN");
  };

  if (loading) {
    return (
      <div className="sample-page">
        <div className="sample-card">
          <p className="sample-state">
            Đang tải dữ liệu...
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="sample-page">
        <div className="error-message">
          {error}
        </div>
      </div>
    );
  }

  if (!transaction) {
    return null;
  }

  return (
    <div className="sample-page transaction-detail-page">
      <div className="sample-page-header">
        <div>
          <h1>Chi tiết giao dịch</h1>

          <p>
            Xem thông tin chi tiết của giao dịch
          </p>
        </div>
      </div>

      <section className="sample-card transaction-detail-card">
        <div className="transaction-detail-header">
          <div>
            <h2>Thông tin giao dịch</h2>

            <p>
              Chi tiết khoản{" "}
              {transaction.type === "income"
                ? "thu nhập"
                : "chi tiêu"}
            </p>
          </div>

          <span
            className={
              transaction.type === "income"
                ? "transaction-detail-type income-detail-type"
                : "transaction-detail-type expense-detail-type"
            }
          >
            {transaction.type === "income"
              ? "Thu nhập"
              : "Chi tiêu"}
          </span>
        </div>
        <div className="transaction-detail-content">
          <div className="transaction-detail-row">
            <span className="transaction-detail-label">
              Số tiền
            </span>

            <strong
              className={
                transaction.type === "income"
                  ? "transaction-detail-money detail-income-money"
                  : "transaction-detail-money detail-expense-money"
              }
            >
              {transaction.type === "income" ? "+" : "-"}
              {formatMoney(transaction.amount)}
            </strong>
          </div>
          <div className="transaction-detail-row">
            <span className="transaction-detail-label">
              Danh mục
            </span>

            <div className="transaction-detail-value category-detail-value">
              <span className="detail-category-icon">
                {transaction.category_icon || "💰"}
              </span>

              <strong>
                {transaction.category_name || "-"}
              </strong>
            </div>
          </div>

          {/* VÍ */}
          <div className="transaction-detail-row">
            <span className="transaction-detail-label">
              Ví / tài khoản
            </span>

            <span className="transaction-detail-value">
              {transaction.wallet_name || "-"}
            </span>
          </div>

          {/* NGÀY */}
          <div className="transaction-detail-row">
            <span className="transaction-detail-label">
              Ngày giao dịch
            </span>

            <span className="transaction-detail-value">
              {formatDate(transaction.transaction_date)}
            </span>
          </div>
          <div className="transaction-detail-row">
            <span className="transaction-detail-label">
              Ghi chú
            </span>

            <span className="transaction-detail-value">
              {transaction.note || "Không có ghi chú"}
            </span>
          </div>
        </div>
        <div className="transaction-detail-actions">
          <Link
            to="/transactions"
            className="detail-back-btn"
          >
            ← Quay lại
          </Link>

          <Link
            to={`/transactions/${transaction.id}/edit`}
            className="detail-edit-btn"
          >
            Sửa giao dịch
          </Link>
        </div>
      </section>
    </div>
  );
}

export default TransactionDetail;