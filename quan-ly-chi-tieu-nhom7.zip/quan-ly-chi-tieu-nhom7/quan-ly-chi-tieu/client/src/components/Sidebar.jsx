import { NavLink, useNavigate } from "react-router-dom";
import {
    LayoutDashboard,
    ArrowLeftRight,
    Tags,
    WalletCards,
    ChartNoAxesCombined,
    CircleDollarSign,
    LogOut,
} from "lucide-react";

function Sidebar() {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");

        navigate("/login");
    };

    return (
        <aside className="sidebar">
            <div className="sidebar-brand">
                <div className="sidebar-logo">
                    <CircleDollarSign size={21} />
                </div>

                <strong>Chi Tiêu Cá Nhân</strong>
            </div>

            <nav className="sidebar-menu">
                <NavLink
                    to="/"
                    end
                    className={({ isActive }) =>
                        `sidebar-item ${isActive ? "active" : ""}`
                    }
                >
                    <LayoutDashboard size={18} />
                    Trang chủ
                </NavLink>

                <NavLink
                    to="/transactions"
                    className={({ isActive }) =>
                        `sidebar-item ${isActive ? "active" : ""}`
                    }
                >
                    <ArrowLeftRight size={18} />
                    Giao dịch
                </NavLink>

                <NavLink
                    to="/categories"
                    className={({ isActive }) =>
                        `sidebar-item ${isActive ? "active" : ""}`
                    }
                >
                    <Tags size={18} />
                    Danh mục
                </NavLink>

                <NavLink
                    to="/wallets"
                    className={({ isActive }) =>
                        `sidebar-item ${isActive ? "active" : ""}`
                    }
                >
                    <WalletCards size={18} />
                    Ví / Tài khoản
                </NavLink>

                <NavLink
                    to="/budgets"
                    className={({ isActive }) =>
                        `sidebar-item ${isActive ? "active" : ""}`
                    }
                >
                    <ChartNoAxesCombined size={18} />
                    Ngân sách
                </NavLink>
            </nav>

            <button
                type="button"
                className="sidebar-logout"
                onClick={handleLogout}
            >
                <LogOut size={18} />
                Đăng xuất
            </button>
        </aside>
    );
}

export default Sidebar;