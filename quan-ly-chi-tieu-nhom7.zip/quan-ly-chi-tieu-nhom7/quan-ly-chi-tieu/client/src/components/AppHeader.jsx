import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { User, Lock, ChevronDown } from "lucide-react";
import useLocalStorage from "../hooks/useLocalStorage";

function AppHeader() {
    const [user] = useLocalStorage("user", null);

    const [showMenu, setShowMenu] = useState(false);

    const menuRef = useRef(null);

    const navigate = useNavigate();

    const getInitial = () => {
        if (!user?.name) return "U";

        return user.name
            .trim()
            .charAt(0)
            .toUpperCase();
    };

    // Bấm ra ngoài thì đóng menu
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (
                menuRef.current &&
                !menuRef.current.contains(event.target)
            ) {
                setShowMenu(false);
            }
        };

        document.addEventListener(
            "mousedown",
            handleClickOutside
        );

        return () => {
            document.removeEventListener(
                "mousedown",
                handleClickOutside
            );
        };
    }, []);

    const handleProfile = () => {
        setShowMenu(false);
        navigate("/profile");
    };

    const handleChangePassword = () => {
        setShowMenu(false);
        navigate("/change-password");
    };

    return (
        <header className="app-header">
            <div></div>

            <div
                className="header-user-wrapper"
                ref={menuRef}
            >
                <button
                    type="button"
                    className="header-user"
                    onClick={() =>
                        setShowMenu(!showMenu)
                    }
                >
                    <div className="header-avatar">
                        {user?.avatar ? (
                            <img
                                src={user.avatar}
                                alt="Ảnh đại diện"
                            />
                        ) : (
                            getInitial()
                        )}
                    </div>

                    <strong>
                        {user?.name || "Người dùng"}
                    </strong>

                    <ChevronDown
                        size={17}
                        className={
                            showMenu
                                ? "header-chevron active"
                                : "header-chevron"
                        }
                    />
                </button>

                {showMenu && (
                    <div className="header-dropdown">
                        <button
                            type="button"
                            onClick={handleProfile}
                        >
                            <User size={18} />

                            <span>Hồ sơ</span>
                        </button>

                        <button
                            type="button"
                            onClick={
                                handleChangePassword
                            }
                        >
                            <Lock size={18} />

                            <span>
                                Đổi mật khẩu
                            </span>
                        </button>
                    </div>
                )}
            </div>
        </header>
    );
}

export default AppHeader;