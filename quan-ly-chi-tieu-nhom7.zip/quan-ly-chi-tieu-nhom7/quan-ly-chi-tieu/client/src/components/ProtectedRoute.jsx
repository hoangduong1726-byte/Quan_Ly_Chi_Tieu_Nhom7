import { Navigate } from "react-router-dom";
import Sidebar from "./Sidebar";
import AppHeader from "./AppHeader";

function ProtectedRoute({ children }) {
  const token = localStorage.getItem("token");

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="app-layout">
      <Sidebar />

      <div className="app-area">
        <AppHeader />

        <main className="app-main">
          {children}
        </main>
      </div>
    </div>
  );
}

export default ProtectedRoute;