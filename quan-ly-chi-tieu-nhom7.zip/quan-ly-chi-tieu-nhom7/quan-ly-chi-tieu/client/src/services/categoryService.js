import axios from "axios";

const API_URL = "http://localhost:5000/api/categories";

const getToken = () => {
  return localStorage.getItem("token");
};

export const getCategories = async () => {
  const response = await axios.get(API_URL, {
    headers: {
      Authorization: `Bearer ${getToken()}`,
    },
  });

  return response.data;
};

export const createCategory = async (category) => {
  const response = await axios.post(API_URL, category, {
    headers: {
      Authorization: `Bearer ${getToken()}`,
    },
  });

  return response.data;
};

export const updateCategory = async (id, category) => {
  const response = await axios.put(`${API_URL}/${id}`, category, {
    headers: {
      Authorization: `Bearer ${getToken()}`,
    },
  });

  return response.data;
};

export const deleteCategory = async (id) => {
  const response = await axios.delete(`${API_URL}/${id}`, {
    headers: {
      Authorization: `Bearer ${getToken()}`,
    },
  });

  return response.data;
};
