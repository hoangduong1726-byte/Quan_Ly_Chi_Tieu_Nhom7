import axios from "axios";

const API_URL = "http://localhost:5000/api/wallets";

const getConfig = () => {
  const token = localStorage.getItem("token");

  return {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };
};

export const getWallets = async () => {
  const response = await axios.get(API_URL, getConfig());

  return response.data;
};

export const createWallet = async (wallet) => {
  const response = await axios.post(API_URL, wallet, getConfig());

  return response.data;
};

export const updateWallet = async (id, wallet) => {
  const response = await axios.put(`${API_URL}/${id}`, wallet, getConfig());

  return response.data;
};

export const deleteWallet = async (id) => {
  const response = await axios.delete(`${API_URL}/${id}`, getConfig());

  return response.data;
};
