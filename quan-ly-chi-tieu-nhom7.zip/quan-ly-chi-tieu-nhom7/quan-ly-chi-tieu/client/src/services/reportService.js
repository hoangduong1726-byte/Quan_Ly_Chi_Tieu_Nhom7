import axios from "axios";

const API_URL =
  "http://localhost:5000/api/reports";

const getConfig = () => {
  const token = localStorage.getItem("token");

  return {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };
};

export const getSummary = async (
  month,
  year
) => {
  const response = await axios.get(
    `${API_URL}/summary`,
    {
      ...getConfig(),

      params: {
        month,
        year,
      },
    }
  );

  return response.data;
};

export const getExpenseByCategory = async (
  month,
  year
) => {
  const response = await axios.get(
    `${API_URL}/expense-by-category`,
    {
      ...getConfig(),

      params: {
        month,
        year,
      },
    }
  );

  return response.data;
};

export const getMonthlyReport = async () => {
  const response = await axios.get(
    `${API_URL}/monthly`,
    getConfig()
  );

  return response.data;
};