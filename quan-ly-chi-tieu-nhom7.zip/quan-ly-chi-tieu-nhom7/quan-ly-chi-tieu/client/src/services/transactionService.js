import axios from "axios";

const API_URL = "http://localhost:5000/api/transactions";

const getConfig = () => {
  const token = localStorage.getItem("token");

  return {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };
};

export const getTransactions = async () => {
  const response = await axios.get(API_URL, getConfig());

  return response.data;
};

export const getTransactionById = async (id) => {
  const response = await axios.get(`${API_URL}/${id}`, getConfig());

  return response.data;
};

export const createTransaction = async (data) => {
  const response = await axios.post(API_URL, data, getConfig());

  return response.data;
};

export const updateTransaction = async (id, data) => {
  const response = await axios.put(`${API_URL}/${id}`, data, getConfig());

  return response.data;
};

export const deleteTransaction = async (id) => {
  const response = await axios.delete(`${API_URL}/${id}`, getConfig());

  return response.data;
};
